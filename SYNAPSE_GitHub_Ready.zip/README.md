# SYNAPSE — Collective Intelligence Network

A real-time collaborative research and epistemic synthesis workspace built for the **Nexconn Build Challenge**. SYNAPSE connects participants across live Nexconn Open Channels and structures fast-moving group conversations into **Observations**, **Hypotheses**, **Evidence**, and **Decisions**.

---

## 1. Problem Statement

High-velocity group discussions in standard chat tools suffer from linear message overload: key empirical citations, hypotheses, and team decisions quickly get buried beneath conversational noise. Meanwhile, naive client-only chat prototypes often expose private API secrets or lack structured synthesis workflows.

## 2. Solution

**SYNAPSE** pairs real-time messaging infrastructure from the **Nexconn Chat SDK** (`@nexconn/engine` and `@nexconn/chat`) with a structured epistemic workflow:

- Every message is tagged as an **Observation**, **Hypothesis**, **Evidence**, or **Decision**.
- Collaborative domain rooms run on Nexconn **Open Channels** with live participant counts, threaded replies, message history queries, and shared room synthesis briefs.
- All **Nexconn Platform Chat API** requests (`access-token/issue`, `open-channel/create`) are signed server-side using SHA-1 (`App-Secret + Nonce + Timestamp`), keeping `NEXCONN_APP_SECRET` completely isolated from browser code.

---

## 3. Features

- **Real-Time Collaborative Rooms**: Join curated domain channels (`Global Commons`, `Climate & Grid Systems`, `Open Biotech Lab`, `Civic & Epistemic Governance`) or provision new Open Channels dynamically.
- **Structured Reasoning Nodes**: Classify messages as `Observation`, `Hypothesis`, `Evidence`, or `Decision` with live client-side filtering and keyword search.
- **Threaded Replies & Shared Room Briefs**: Quote specific nodes using `SendReferenceMessageParams` and pin consensus summaries via Nexconn Open Channel metadata (`setMetadata` / `getMetadata`).
- **Synthesis Ledger & Markdown Export**: View aggregated reasoning nodes across channels and export a clean `.md` synthesis brief.
- **Server-Side Security & Failover**: Computes Nexconn SHA-1 request signatures on the server with automatic primary/backup regional domain failover (`SG`, `NA`, `SAU`), input validation, and IP rate limiting.
- **Responsive Multi-Route UI**: Desktop sidebar layout and mobile room-switcher drawer with SPA routing, loading skeletons, error recovery states, and a custom 404 page.

---

## 4. Technology Stack

- **Frontend**: React 19, TypeScript, React Router DOM, Tailwind CSS v4, Lucide React
- **Real-Time Messaging**: `@nexconn/chat` (`26.5.1`), `@nexconn/engine` (`26.5.1`)
- **Backend / Serverless**: Express (`server.ts`) for local/container hosting and Vercel Serverless Functions (`api/*.ts`) for Vercel deployment
- **Build Tooling**: Vite 8, `tsx`

---

## 5. Nexconn SDK Integration

SYNAPSE uses official Nexconn SDKs and Platform Chat APIs without mock fallbacks:

1. **Server-Side Token Issuance (`/api/nexconn/token`)**:
   - Computes `Signature = sha1(NEXCONN_APP_SECRET + Nonce + Timestamp)`
   - Calls `POST /v4/auth/access-token/issue` on the regional Nexconn host (`api.sg-light-api.com`, `api.us-light-api.com`, or `api.sau-light-api.com`) with backup domain failover.
2. **Server-Side Room Provisioning (`/api/nexconn/rooms`)**:
   - Calls `POST /v4/open-channel/create` so every room exists on Nexconn before participants enter.
3. **Client SDK Lifecycle (`src/lib/nexconnClient.ts`)**:
   - Calls `NCEngine.initialize({ appKey, areaCode, logLevel })` once per app lifecycle.
   - Registers `ConnectionStatusHandler`, `MessageHandler`, and `OpenChannelHandler`.
   - Authenticates via `NCEngine.connect({ token })`.
   - Enters rooms via `new OpenChannel(channelId).enterChannel({ messageCount: 30 })`, loads history via `OpenChannel.createOpenChannelMessagesQuery(...)`, and sends messages via `SendTextMessageParams` and `SendReferenceMessageParams`.

---

## 6. Installation

```bash
git clone https://github.com/<your-username>/synapse-collective-intelligence.git
cd synapse-collective-intelligence
npm install
```

---

## 7. Environment Variable Setup

Copy `.env.example` to `.env.local` (for local development) and never commit `.env*` files:

```bash
cp .env.example .env.local
```

Configure the following variables (from your [Nexconn Console Key Management](https://console.nexconn.ai/agile/apps/km) page):

| Variable | Scope | Required | Description |
| --- | --- | --- | --- |
| `NEXCONN_APP_KEY` | Server (and shared via `/api/nexconn/config`) | Yes | Your public Nexconn App Key |
| `NEXCONN_APP_SECRET` | Server-only (`process.env`) | Yes | Your private Nexconn App Secret (never expose in frontend code) |
| `NEXCONN_REGION` | Server & Client | No | `SG` (default), `NA`, or `SAU` |
| `VITE_NEXCONN_APP_KEY` | Client (optional) | No | Optional public build-time override for `App-Key` |
| `VITE_NEXCONN_REGION` | Client (optional) | No | Optional public build-time override for region |
| `APP_URL` | Server / Runtime | No | Deployed application base URL |

---

## 8. Local Development

Start the full-stack development server (Express API + Vite middleware on port `3000`):

```bash
npm run dev
```

Open `http://localhost:3000` in your browser.

Type-check and build verification:

```bash
npm run lint
npm run build
```

---

## 9. Production Deployment (Vercel)

1. Push this repository (`synapse-collective-intelligence`) to GitHub.
2. Import the repository in [Vercel](https://vercel.com/new).
3. Verify the build settings (pre-configured in `vercel.json`):
   - **Framework Preset**: `Vite`
   - **Build Command**: `npm run build`
   - **Output Directory**: `dist`
4. Add environment variables in **Vercel Project Settings -> Environment Variables**:
   - `NEXCONN_APP_KEY`
   - `NEXCONN_APP_SECRET`
   - `NEXCONN_REGION` (`SG`, `NA`, or `SAU`)
5. Deploy. Vercel automatically serves the static Vite bundle from `dist/`, routes `/api/*` to the serverless functions in `api/`, and applies SPA fallback rewrites for `/workspaces/:roomId`, `/synthesis`, and `/architecture`.

---

## 10. Visuals & Screenshots

Visual assets included in `src/assets/images/`:
- Network Overview visual (`synapse_network_hero_1795317660273.jpg`)
- Structured Synthesis Grid visual (`synapse_synthesis_grid_1795317660022.jpg`)

*(Add live deployment screenshots from `/workspaces` and `/synthesis` here after deploying and connecting your Nexconn session.)*

---

## 11. Team Credits

- **SYNAPSE Team** — Project development and implementation.
- *Add team member names only if you want them displayed publicly.*

---

## 12. License

No open-source license file (`LICENSE`) has been added yet. Confirm your preferred license (e.g., MIT or Apache-2.0) before publishing publicly.

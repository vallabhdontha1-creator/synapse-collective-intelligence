import {
  AreaCode,
  ConnectionStatus,
  ConnectionStatusHandler,
  LogLevel,
  Message,
  MessageHandler,
  NCEngine,
  OpenChannel,
  OpenChannelHandler,
  SendReferenceMessageParams,
  SendTextMessageParams,
} from '@nexconn/chat';
import type {
  IntelligenceNodeType,
  NexconnRegion,
  SynapseMessage,
  SynapseMessageReply,
} from '../types/synapse';

let initializedAppKey: string | null = null;
let handlersRegistered = false;
let activeOpenChannel: OpenChannel | null = null;
let activeOpenChannelId: string | null = null;

export interface NexconnCallbacks {
  onConnectionStatus?: (status: ConnectionStatus, code?: number) => void;
  onMessageReceived?: (messages: SynapseMessage[]) => void;
  onParticipantCountChanged?: (channelId: string, participantCount: number) => void;
  onMetadataChanged?: (channelId: string, metadata: Record<string, string>) => void;
  onChannelExited?: (channelId: string) => void;
  onChannelDestroyed?: (channelId: string) => void;
}

const currentCallbacks: NexconnCallbacks = {};

export function setNexconnCallbacks(callbacks: NexconnCallbacks) {
  Object.assign(currentCallbacks, callbacks);
}

function mapRegionToAreaCode(region: NexconnRegion): AreaCode {
  switch (region) {
    case 'NA':
      return AreaCode.NA;
    case 'SAU':
      return AreaCode.OM;
    case 'SG':
    default:
      return AreaCode.SG;
  }
}

export function initializeNexconnSDK(appKey: string, region: NexconnRegion): void {
  if (!appKey) {
    throw new Error('Cannot initialize Nexconn SDK without a valid App Key.');
  }

  // Official Nexconn rule: NCEngine.initialize must only be called once in app lifecycle
  if (!initializedAppKey) {
    NCEngine.initialize({
      appKey,
      areaCode: mapRegionToAreaCode(region),
      logLevel: LogLevel.WARN,
    });
    initializedAppKey = appKey;
  }

  if (!handlersRegistered) {
    NCEngine.addConnectionStatusHandler(
      'synapse-connection-handler',
      new ConnectionStatusHandler({
        onConnectionStatusChanged({ status, code }) {
          currentCallbacks.onConnectionStatus?.(status, code);
        },
      }),
    );

    NCEngine.addMessageHandler(
      'synapse-message-handler',
      new MessageHandler({
        onMessageReceived({ messages }) {
          const parsed = messages
            .map((msg) => parseNexconnMessage(msg))
            .filter((item): item is SynapseMessage => item !== null);
          if (parsed.length > 0) {
            currentCallbacks.onMessageReceived?.(parsed);
          }
        },
      }),
    );

    NCEngine.addOpenChannelHandler(
      'synapse-open-channel-handler',
      new OpenChannelHandler({
        onEntered({ channelId, response }) {
          currentCallbacks.onParticipantCountChanged?.(channelId, response.participantCount);
        },
        onParticipantChanged({ channelId, participantCount }) {
          currentCallbacks.onParticipantCountChanged?.(channelId, participantCount);
        },
        onMetadataChanged({ changeInfo }) {
          const grouped: Record<string, Record<string, string>> = {};
          for (const item of changeInfo) {
            if (!grouped[item.channelId]) grouped[item.channelId] = {};
            grouped[item.channelId][item.key] = item.value;
          }
          for (const [channelId, metadata] of Object.entries(grouped)) {
            currentCallbacks.onMetadataChanged?.(channelId, metadata);
          }
        },
        onExited({ channelId }) {
          currentCallbacks.onChannelExited?.(channelId);
        },
        onChannelDestroyed({ channelId }) {
          currentCallbacks.onChannelDestroyed?.(channelId);
        },
      }),
    );

    handlersRegistered = true;
  }
}

export async function connectToNexconn(token: string): Promise<{ userId: string }> {
  const result = await NCEngine.connect({ token });
  if (!result.isOk || !result.data) {
    throw new Error(`Nexconn connection failed (code: ${result.code})`);
  }
  return { userId: result.data.userId };
}

export async function disconnectFromNexconn(): Promise<void> {
  if (activeOpenChannel) {
    try {
      await activeOpenChannel.exitChannel();
    } catch {
      // Ignore exit errors during teardown
    }
    activeOpenChannel = null;
    activeOpenChannelId = null;
  }
  await NCEngine.disconnect();
}

export async function enterCollaborativeOpenChannel(
  channelId: string,
  displayName: string,
): Promise<{
  participantCount: number;
  history: SynapseMessage[];
  metadata: Record<string, string>;
}> {
  if (activeOpenChannel && activeOpenChannelId && activeOpenChannelId !== channelId) {
    try {
      await activeOpenChannel.exitChannel();
    } catch {
      // Proceed even if prior channel already closed
    }
    activeOpenChannel = null;
    activeOpenChannelId = null;
  }

  const channel = new OpenChannel(channelId);
  const enterResult = await channel.enterChannel({
    messageCount: 30,
    extra: displayName,
  });

  if (!enterResult.isOk || !enterResult.data) {
    throw new Error(`Failed to join Nexconn open channel "${channelId}" (code: ${enterResult.code})`);
  }

  activeOpenChannel = channel;
  activeOpenChannelId = channelId;

  // Fetch remote history if Open Channel cloud retention is enabled on the Nexconn key
  let history: SynapseMessage[] = [];
  try {
    const query = OpenChannel.createOpenChannelMessagesQuery({
      channelId,
      pageSize: 30,
      isAscending: true,
      startTime: 0,
    });
    const pageResult = await query.loadNextPage();
    if (pageResult.isOk && pageResult.data?.data) {
      history = pageResult.data.data
        .map((msg) => parseNexconnMessage(msg, channelId))
        .filter((item): item is SynapseMessage => item !== null);
    }
  } catch {
    // Cloud retention may be off on free tier; live messages still work
  }

  // Fetch shared channel metadata if enabled
  let metadata: Record<string, string> = {};
  try {
    const metaRes = await channel.getMetadata();
    if (metaRes.isOk && metaRes.data) {
      metadata = metaRes.data;
    }
  } catch {
    // Open channel KV metadata may require enabling in Nexconn console
  }

  return {
    participantCount: enterResult.data.participantCount,
    history,
    metadata,
  };
}

export async function sendCollaborativeMessage(params: {
  channelId: string;
  text: string;
  nodeType: IntelligenceNodeType;
  authorName: string;
  replyTo?: {
    messageId: string;
    senderUserId: string;
    text: string;
  };
}): Promise<SynapseMessage> {
  if (!activeOpenChannel || activeOpenChannelId !== params.channelId) {
    throw new Error('You must join this open channel before sending messages.');
  }

  const extraPayload = JSON.stringify({
    nodeType: params.nodeType,
    authorName: params.authorName,
  });

  if (params.replyTo) {
    const refParams = new SendReferenceMessageParams({
      text: params.text,
      referMsgId: params.replyTo.messageId,
      referMsgSenderId: params.replyTo.senderUserId,
      referMsgType: 'RC:TxtMsg',
      referMsg: { text: params.replyTo.text },
      extra: extraPayload,
    });
    const sendRes = await activeOpenChannel.sendMessage(refParams);
    if (!sendRes.isOk || !sendRes.data) {
      throw new Error(`Failed to send reply message (code: ${sendRes.code})`);
    }
    const parsed = parseNexconnMessage(sendRes.data, params.channelId);
    if (!parsed) {
      throw new Error('Sent message returned an unexpected payload.');
    }
    return parsed;
  }

  const textParams = new SendTextMessageParams({
    text: params.text,
    extra: extraPayload,
  });

  const sendRes = await activeOpenChannel.sendMessage(textParams);
  if (!sendRes.isOk || !sendRes.data) {
    throw new Error(`Failed to send message (code: ${sendRes.code})`);
  }

  const parsed = parseNexconnMessage(sendRes.data, params.channelId);
  if (!parsed) {
    throw new Error('Sent message returned an unexpected payload.');
  }
  return parsed;
}

export async function saveRoomSynthesisBrief(
  channelId: string,
  brief: string,
): Promise<{ ok: boolean; error?: string }> {
  if (!activeOpenChannel || activeOpenChannelId !== channelId) {
    return { ok: false, error: 'Join the room first to update its shared brief.' };
  }
  const res = await activeOpenChannel.setMetadata({
    metadata: { synthesis_brief: brief },
    deleteWhenLeft: false,
  });
  if (!res.isOk) {
    return {
      ok: false,
      error: `Nexconn Open Channel metadata returned code ${res.code}. Ensure Open Channel KV Metadata is enabled in your Nexconn Console.`,
    };
  }
  return { ok: true };
}

function isNodeType(val: unknown): val is IntelligenceNodeType {
  return val === 'observation' || val === 'hypothesis' || val === 'evidence' || val === 'decision';
}

export function parseNexconnMessage(
  msg: Message<any>,
  fallbackChannelId?: string,
): SynapseMessage | null {
  const content = (msg.content || {}) as Record<string, unknown>;
  const text =
    typeof content.text === 'string'
      ? content.text
      : typeof content.content === 'string'
        ? content.content
        : '';

  if (!text.trim()) {
    return null;
  }

  let nodeType: IntelligenceNodeType = 'observation';
  let authorName = msg.senderUserId || 'Participant';

  if (typeof content.extra === 'string' && content.extra.trim().startsWith('{')) {
    try {
      const parsedExtra = JSON.parse(content.extra) as {
        nodeType?: unknown;
        authorName?: unknown;
      };
      if (isNodeType(parsedExtra.nodeType)) {
        nodeType = parsedExtra.nodeType;
      }
      if (typeof parsedExtra.authorName === 'string' && parsedExtra.authorName.trim()) {
        authorName = parsedExtra.authorName.trim();
      }
    } catch {
      // Fall back to defaults if extra is plain text
    }
  }

  let replyTo: SynapseMessageReply | undefined;
  if (typeof content.referMsgId === 'string' && content.referMsgId) {
    const referMsg = content.referMsg as Record<string, unknown> | undefined;
    const referText =
      typeof referMsg?.text === 'string'
        ? referMsg.text
        : typeof referMsg?.content === 'string'
          ? referMsg.content
          : 'Referenced node';
    replyTo = {
      messageId: content.referMsgId,
      senderUserId:
        typeof content.referMsgSenderId === 'string' ? content.referMsgSenderId : 'participant',
      text: referText,
    };
  }

  const channelId = msg.channelIdentifier?.channelId || fallbackChannelId || 'synapse-global-commons';

  return {
    messageId: msg.messageId || `${msg.senderUserId}-${msg.sentTime}-${Math.random().toString(36).slice(2, 7)}`,
    channelId,
    senderUserId: msg.senderUserId || 'anonymous',
    authorName,
    nodeType,
    text,
    sentTime: msg.sentTime || Date.now(),
    replyTo,
  };
}

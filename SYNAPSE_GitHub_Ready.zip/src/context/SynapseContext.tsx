import React, { createContext, useCallback, useContext, useEffect, useMemo, useState } from 'react';
import { ConnectionStatus } from '@nexconn/chat';
import {
  connectToNexconn,
  disconnectFromNexconn,
  enterCollaborativeOpenChannel,
  initializeNexconnSDK,
  saveRoomSynthesisBrief,
  sendCollaborativeMessage,
  setNexconnCallbacks,
} from '../lib/nexconnClient';
import type {
  IntelligenceNodeType,
  NexconnConnectionState,
  NexconnPublicConfig,
  NexconnRegion,
  SynapseMessage,
  SynapseRoom,
} from '../types/synapse';

interface IdentityProfile {
  userId: string;
  displayName: string;
}

interface SynapseContextValue {
  config: NexconnPublicConfig | null;
  connectionState: NexconnConnectionState;
  connectionError: string | null;
  identity: IdentityProfile;
  rooms: SynapseRoom[];
  roomsLoading: boolean;
  activeRoomId: string | null;
  joiningRoom: boolean;
  roomError: string | null;
  participantCounts: Record<string, number>;
  roomBriefs: Record<string, string>;
  messagesByRoom: Record<string, SynapseMessage[]>;
  connectSession: (userId: string, displayName: string) => Promise<boolean>;
  disconnectSession: () => Promise<void>;
  joinRoom: (channelId: string) => Promise<void>;
  createRoom: (params: {
    channelId: string;
    name: string;
    domain: string;
    description: string;
  }) => Promise<SynapseRoom | null>;
  sendNodeMessage: (params: {
    channelId: string;
    text: string;
    nodeType: IntelligenceNodeType;
    replyTo?: { messageId: string; senderUserId: string; text: string };
  }) => Promise<boolean>;
  updateRoomBrief: (channelId: string, brief: string) => Promise<{ ok: boolean; error?: string }>;
  clearErrors: () => void;
}

const SynapseContext = createContext<SynapseContextValue | null>(null);

const IDENTITY_STORAGE_KEY = 'synapse_identity_profile';

function generateDefaultIdentity(): IdentityProfile {
  try {
    const saved = sessionStorage.getItem(IDENTITY_STORAGE_KEY);
    if (saved) {
      const parsed = JSON.parse(saved) as Partial<IdentityProfile>;
      if (parsed.userId && parsed.displayName) {
        return { userId: parsed.userId, displayName: parsed.displayName };
      }
    }
  } catch {
    // Ignore storage access failures
  }
  const suffix = Math.random().toString(36).slice(2, 6);
  return {
    userId: `researcher_${suffix}`,
    displayName: `Researcher ${suffix.toUpperCase()}`,
  };
}

function mapSdkStatus(status: ConnectionStatus): NexconnConnectionState {
  switch (status) {
    case ConnectionStatus.CONNECTED:
      return 'connected';
    case ConnectionStatus.CONNECTING:
      return 'connecting';
    case ConnectionStatus.SUSPENDED:
      return 'suspended';
    case ConnectionStatus.DISCONNECTED:
    default:
      return 'disconnected';
  }
}

function mergeUniqueMessages(existing: SynapseMessage[], incoming: SynapseMessage[]): SynapseMessage[] {
  const map = new Map<string, SynapseMessage>();
  for (const m of existing) {
    map.set(m.messageId, m);
  }
  for (const m of incoming) {
    map.set(m.messageId, m);
  }
  return Array.from(map.values()).sort((a, b) => a.sentTime - b.sentTime);
}

export function SynapseProvider({ children }: { children: React.ReactNode }) {
  const [config, setConfig] = useState<NexconnPublicConfig | null>(null);
  const [connectionState, setConnectionState] = useState<NexconnConnectionState>('loading-config');
  const [connectionError, setConnectionError] = useState<string | null>(null);
  const [identity, setIdentity] = useState<IdentityProfile>(generateDefaultIdentity);
  const [rooms, setRooms] = useState<SynapseRoom[]>([]);
  const [roomsLoading, setRoomsLoading] = useState<boolean>(true);
  const [activeRoomId, setActiveRoomId] = useState<string | null>(null);
  const [joiningRoom, setJoiningRoom] = useState<boolean>(false);
  const [roomError, setRoomError] = useState<string | null>(null);
  const [participantCounts, setParticipantCounts] = useState<Record<string, number>>({});
  const [roomBriefs, setRoomBriefs] = useState<Record<string, string>>({});
  const [messagesByRoom, setMessagesByRoom] = useState<Record<string, SynapseMessage[]>>({});

  // Register Nexconn SDK callbacks
  useEffect(() => {
    setNexconnCallbacks({
      onConnectionStatus(status, code) {
        setConnectionState(mapSdkStatus(status));
        if (code && status === ConnectionStatus.DISCONNECTED) {
          setConnectionError(`Nexconn connection closed (code: ${code}).`);
        }
      },
      onMessageReceived(incoming) {
        setMessagesByRoom((prev) => {
          const next = { ...prev };
          for (const msg of incoming) {
            const currentList = next[msg.channelId] || [];
            next[msg.channelId] = mergeUniqueMessages(currentList, [msg]);
          }
          return next;
        });
      },
      onParticipantCountChanged(channelId, count) {
        setParticipantCounts((prev) => ({ ...prev, [channelId]: count }));
      },
      onMetadataChanged(channelId, metadata) {
        if (typeof metadata.synthesis_brief === 'string') {
          setRoomBriefs((prev) => ({ ...prev, [channelId]: metadata.synthesis_brief }));
        }
      },
      onChannelExited(channelId) {
        setActiveRoomId((curr) => (curr === channelId ? null : curr));
      },
      onChannelDestroyed(channelId) {
        setActiveRoomId((curr) => (curr === channelId ? null : curr));
        setRoomError(`Open channel "${channelId}" was closed or expired.`);
      },
    });
  }, []);

  // Load initial public Nexconn config & room directory
  useEffect(() => {
    let cancelled = false;
    async function bootstrap() {
      try {
        const [configRes, roomsRes] = await Promise.all([
          fetch('/api/nexconn/config'),
          fetch('/api/nexconn/rooms'),
        ]);

        if (roomsRes.ok) {
          const roomsJson = (await roomsRes.json()) as { rooms?: SynapseRoom[] };
          if (!cancelled && Array.isArray(roomsJson.rooms)) {
            setRooms(roomsJson.rooms);
          }
        }

        if (configRes.ok) {
          const cfg = (await configRes.json()) as NexconnPublicConfig;
          const fallbackClientKey = (import.meta.env.VITE_NEXCONN_APP_KEY || '').trim();
          const fallbackRegion = (import.meta.env.VITE_NEXCONN_REGION || 'SG').toUpperCase() as NexconnRegion;
          const resolvedConfig: NexconnPublicConfig = {
            configured: cfg.configured,
            appKey: cfg.appKey || fallbackClientKey,
            region: cfg.region || fallbackRegion,
            missing: cfg.missing || [],
          };

          if (!cancelled) {
            setConfig(resolvedConfig);
            if (!resolvedConfig.configured || !resolvedConfig.appKey) {
              setConnectionState('unconfigured');
            } else {
              setConnectionState('idle');
            }
          }
        } else if (!cancelled) {
          setConnectionState('error');
          setConnectionError('Unable to reach /api/nexconn/config.');
        }
      } catch (err) {
        if (!cancelled) {
          setConnectionState('error');
          setConnectionError(
            err instanceof Error ? err.message : 'Failed to initialize SYNAPSE configuration.',
          );
        }
      } finally {
        if (!cancelled) {
          setRoomsLoading(false);
        }
      }
    }
    bootstrap();
    return () => {
      cancelled = true;
    };
  }, []);

  const connectSession = useCallback(
    async (rawUserId: string, rawDisplayName: string): Promise<boolean> => {
      const userId = rawUserId.trim().replace(/[^a-zA-Z0-9_-]/g, '_');
      const displayName = rawDisplayName.trim();

      if (!userId || userId.length < 2) {
        setConnectionError('Handle must be at least 2 alphanumeric, underscore, or hyphen characters.');
        return false;
      }
      if (!displayName) {
        setConnectionError('Display name is required.');
        return false;
      }
      if (!config?.configured || !config.appKey) {
        setConnectionState('unconfigured');
        setConnectionError(
          'Nexconn App Key and App Secret must be configured on the server before connecting.',
        );
        return false;
      }

      setConnectionError(null);
      setConnectionState('connecting');

      try {
        try {
          sessionStorage.setItem(
            IDENTITY_STORAGE_KEY,
            JSON.stringify({ userId, displayName }),
          );
        } catch {
          // Ignore sessionStorage errors
        }
        setIdentity({ userId, displayName });

        initializeNexconnSDK(config.appKey, config.region);

        const tokenRes = await fetch('/api/nexconn/token', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ userId, name: displayName }),
        });

        const tokenData = (await tokenRes.json()) as {
          accessToken?: string;
          userId?: string;
          error?: string;
        };

        if (!tokenRes.ok || !tokenData.accessToken) {
          throw new Error(tokenData.error || 'Failed to obtain Nexconn access token from server.');
        }

        await connectToNexconn(tokenData.accessToken);
        setConnectionState('connected');
        return true;
      } catch (err) {
        setConnectionState('error');
        setConnectionError(
          err instanceof Error ? err.message : 'Failed to connect to Nexconn real-time network.',
        );
        return false;
      }
    },
    [config],
  );

  const disconnectSession = useCallback(async () => {
    try {
      await disconnectFromNexconn();
    } finally {
      setActiveRoomId(null);
      setConnectionState(config?.configured ? 'idle' : 'unconfigured');
    }
  }, [config]);

  const joinRoom = useCallback(
    async (channelId: string) => {
      if (connectionState !== 'connected') {
        setRoomError('Connect to the Nexconn network before joining a collaborative room.');
        return;
      }

      setJoiningRoom(true);
      setRoomError(null);

      try {
        // Ensure OpenChannel exists on Nexconn via server endpoint
        const ensureRes = await fetch('/api/nexconn/rooms', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ channelId }),
        });
        const ensureData = (await ensureRes.json()) as { room?: SynapseRoom; error?: string };
        if (!ensureRes.ok) {
          throw new Error(ensureData.error || 'Failed to prepare Nexconn open channel.');
        }

        if (ensureData.room) {
          setRooms((prev) => {
            if (prev.some((r) => r.channelId === ensureData.room!.channelId)) return prev;
            return [...prev, ensureData.room!];
          });
        }

        const joined = await enterCollaborativeOpenChannel(channelId, identity.displayName);
        setActiveRoomId(channelId);
        setParticipantCounts((prev) => ({ ...prev, [channelId]: joined.participantCount }));

        if (typeof joined.metadata.synthesis_brief === 'string') {
          setRoomBriefs((prev) => ({ ...prev, [channelId]: joined.metadata.synthesis_brief }));
        }

        if (joined.history.length > 0) {
          setMessagesByRoom((prev) => ({
            ...prev,
            [channelId]: mergeUniqueMessages(prev[channelId] || [], joined.history),
          }));
        }
      } catch (err) {
        setRoomError(err instanceof Error ? err.message : 'Failed to enter collaborative room.');
      } finally {
        setJoiningRoom(false);
      }
    },
    [connectionState, identity.displayName],
  );

  const createRoom = useCallback(
    async (params: {
      channelId: string;
      name: string;
      domain: string;
      description: string;
    }): Promise<SynapseRoom | null> => {
      setRoomError(null);
      try {
        const res = await fetch('/api/nexconn/rooms', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(params),
        });
        const data = (await res.json()) as { room?: SynapseRoom; error?: string };
        if (!res.ok || !data.room) {
          throw new Error(data.error || 'Failed to create collaborative room.');
        }
        setRooms((prev) => {
          if (prev.some((r) => r.channelId === data.room!.channelId)) return prev;
          return [...prev, data.room!];
        });
        return data.room;
      } catch (err) {
        setRoomError(err instanceof Error ? err.message : 'Unable to create room.');
        return null;
      }
    },
    [],
  );

  const sendNodeMessage = useCallback(
    async (params: {
      channelId: string;
      text: string;
      nodeType: IntelligenceNodeType;
      replyTo?: { messageId: string; senderUserId: string; text: string };
    }): Promise<boolean> => {
      setRoomError(null);
      try {
        const sent = await sendCollaborativeMessage({
          channelId: params.channelId,
          text: params.text,
          nodeType: params.nodeType,
          authorName: identity.displayName,
          replyTo: params.replyTo,
        });
        setMessagesByRoom((prev) => ({
          ...prev,
          [params.channelId]: mergeUniqueMessages(prev[params.channelId] || [], [sent]),
        }));
        return true;
      } catch (err) {
        setRoomError(err instanceof Error ? err.message : 'Failed to transmit message.');
        return false;
      }
    },
    [identity.displayName],
  );

  const updateRoomBrief = useCallback(async (channelId: string, brief: string) => {
    const res = await saveRoomSynthesisBrief(channelId, brief);
    if (res.ok) {
      setRoomBriefs((prev) => ({ ...prev, [channelId]: brief }));
    }
    return res;
  }, []);

  const clearErrors = useCallback(() => {
    setConnectionError(null);
    setRoomError(null);
  }, []);

  const value = useMemo<SynapseContextValue>(
    () => ({
      config,
      connectionState,
      connectionError,
      identity,
      rooms,
      roomsLoading,
      activeRoomId,
      joiningRoom,
      roomError,
      participantCounts,
      roomBriefs,
      messagesByRoom,
      connectSession,
      disconnectSession,
      joinRoom,
      createRoom,
      sendNodeMessage,
      updateRoomBrief,
      clearErrors,
    }),
    [
      config,
      connectionState,
      connectionError,
      identity,
      rooms,
      roomsLoading,
      activeRoomId,
      joiningRoom,
      roomError,
      participantCounts,
      roomBriefs,
      messagesByRoom,
      connectSession,
      disconnectSession,
      joinRoom,
      createRoom,
      sendNodeMessage,
      updateRoomBrief,
      clearErrors,
    ],
  );

  return <SynapseContext.Provider value={value}>{children}</SynapseContext.Provider>;
}

export function useSynapse() {
  const ctx = useContext(SynapseContext);
  if (!ctx) {
    throw new Error('useSynapse must be used inside a SynapseProvider.');
  }
  return ctx;
}

import { Link, useLocation } from 'react-router-dom';

export function NotFoundPage() {
  const location = useLocation();

  return (
    <div className="mx-auto flex w-full max-w-[1360px] flex-1 items-center justify-center px-4 py-20 sm:px-6 lg:px-8">
      <div className="max-w-lg w-full rounded-xl border border-slate-200 bg-white p-8 text-center">
        <p className="font-mono text-xs font-semibold uppercase tracking-wider text-indigo-700">
          Error 404
        </p>
        <h1 className="mt-2 font-display text-3xl font-bold tracking-tight text-slate-900">
          Channel or route not found
        </h1>
        <p className="mt-3 text-sm leading-relaxed text-slate-600">
          The requested path{' '}
          <code className="rounded bg-slate-100 px-1.5 py-0.5 font-mono text-xs text-slate-800">
            {location.pathname}
          </code>{' '}
          does not match an active workspace or page in SYNAPSE.
        </p>
        <div className="mt-7 flex flex-wrap items-center justify-center gap-3">
          <Link
            to="/"
            className="inline-flex min-h-[42px] items-center rounded-lg bg-indigo-700 px-4 py-2 text-sm font-medium text-white hover:bg-indigo-800"
          >
            Return to Network Overview
          </Link>
          <Link
            to="/workspaces"
            className="inline-flex min-h-[42px] items-center rounded-lg border border-slate-200 bg-white px-4 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50"
          >
            Open Workspaces
          </Link>
        </div>
      </div>
    </div>
  );
}

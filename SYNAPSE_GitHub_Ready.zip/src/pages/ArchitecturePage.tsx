import { Link } from 'react-router-dom';
import { ArrowRight, KeyRound, Lock, Radio, Server } from 'lucide-react';
import { useSynapse } from '../context/SynapseContext';

export function ArchitecturePage() {
  const { config } = useSynapse();

  return (
    <div className="mx-auto w-full max-w-[1360px] flex-1 px-4 py-10 sm:px-6 lg:px-8">
      <div className="border-b border-slate-200 pb-6">
        <p className="text-sm font-medium text-indigo-700">System Design & Security Model</p>
        <h1 className="mt-2 font-display text-3xl font-bold tracking-tight text-slate-900">
          Nexconn SDK & Server Architecture
        </h1>
        <p className="mt-2 max-w-2xl text-sm leading-relaxed text-slate-600">
          SYNAPSE separates public real-time client transport from private credential signing so
          your Nexconn App Secret is never exposed to browsers or committed to GitHub.
        </p>
      </div>

      {/* 3-Layer Stack */}
      <div className="mt-8 grid grid-cols-1 gap-6 md:grid-cols-3">
        <div className="rounded-xl border border-slate-200 bg-white p-6">
          <div className="flex items-center gap-2.5 text-sm font-semibold text-slate-900">
            <Radio className="h-4 w-4 text-indigo-700" aria-hidden="true" />
            <span>01. Client Real-Time SDK</span>
          </div>
          <p className="mt-3 text-sm leading-relaxed text-slate-600">
            Initializes <code className="font-mono text-xs text-slate-800">@nexconn/chat</code>{' '}
            (<code className="font-mono text-xs text-slate-800">NCEngine.initialize</code>) once per
            session using the public App Key and regional <code className="font-mono text-xs">AreaCode</code>,
            then connects with short-lived server-issued user tokens.
          </p>
        </div>

        <div className="rounded-xl border border-slate-200 bg-white p-6">
          <div className="flex items-center gap-2.5 text-sm font-semibold text-slate-900">
            <Server className="h-4 w-4 text-indigo-700" aria-hidden="true" />
            <span>02. Signed Token & Room API</span>
          </div>
          <p className="mt-3 text-sm leading-relaxed text-slate-600">
            Backend endpoints (<code className="font-mono text-xs">/api/nexconn/token</code> and{' '}
            <code className="font-mono text-xs">/api/nexconn/rooms</code>) compute{' '}
            <code className="font-mono text-xs">SHA1(AppSecret + Nonce + Timestamp)</code> and call{' '}
            <code className="font-mono text-xs">/v4/auth/access-token/issue</code> and{' '}
            <code className="font-mono text-xs">/v4/open-channel/create</code> with primary/backup
            domain failover.
          </p>
        </div>

        <div className="rounded-xl border border-slate-200 bg-white p-6">
          <div className="flex items-center gap-2.5 text-sm font-semibold text-slate-900">
            <Lock className="h-4 w-4 text-indigo-700" aria-hidden="true" />
            <span>03. Secret Isolation</span>
          </div>
          <p className="mt-3 text-sm leading-relaxed text-slate-600">
            <code className="font-mono text-xs">NEXCONN_APP_SECRET</code> stays exclusively in
            server-side <code className="font-mono text-xs">process.env</code> across both Express
            (<code className="font-mono text-xs">server.ts</code>) and Vercel Serverless Functions (
            <code className="font-mono text-xs">api/nexconn/*.ts</code>).
          </p>
        </div>
      </div>

      {/* Live Environment Status Checklist */}
      <div className="mt-10 rounded-xl border border-slate-200 bg-white p-6">
        <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
          <div className="flex items-center gap-2.5">
            <KeyRound className="h-4 w-4 text-indigo-700" aria-hidden="true" />
            <h2 className="font-display text-lg font-semibold text-slate-900">
              Runtime Environment Verification
            </h2>
          </div>
          <Link
            to="/workspaces"
            className="inline-flex items-center gap-1.5 text-sm font-medium text-indigo-700 hover:text-indigo-800"
          >
            <span>Test Live Connection</span>
            <ArrowRight className="h-4 w-4" />
          </Link>
        </div>

        <div className="mt-5 overflow-x-auto">
          <table className="w-full text-left text-sm">
            <thead>
              <tr className="border-b border-slate-200 text-xs text-slate-500">
                <th className="py-2.5 pr-4 font-medium">Variable</th>
                <th className="py-2.5 pr-4 font-medium">Scope</th>
                <th className="py-2.5 pr-4 font-medium">Purpose</th>
                <th className="py-2.5 font-medium">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-xs">
              <tr>
                <td className="py-3 pr-4 font-mono text-slate-900">NEXCONN_APP_KEY</td>
                <td className="py-3 pr-4 text-slate-600">Server & Client Init</td>
                <td className="py-3 pr-4 text-slate-600">Identifies your Nexconn application</td>
                <td className="py-3 font-medium">
                  {config?.appKey ? (
                    <span className="text-emerald-700">Present</span>
                  ) : (
                    <span className="text-amber-700">Missing</span>
                  )}
                </td>
              </tr>
              <tr>
                <td className="py-3 pr-4 font-mono text-slate-900">NEXCONN_APP_SECRET</td>
                <td className="py-3 pr-4 text-slate-600">Server-Side Only</td>
                <td className="py-3 pr-4 text-slate-600">Signs Platform Chat API requests</td>
                <td className="py-3 font-medium">
                  {config?.configured ? (
                    <span className="text-emerald-700">Configured</span>
                  ) : (
                    <span className="text-amber-700">Missing</span>
                  )}
                </td>
              </tr>
              <tr>
                <td className="py-3 pr-4 font-mono text-slate-900">NEXCONN_REGION</td>
                <td className="py-3 pr-4 text-slate-600">Server & Client Init</td>
                <td className="py-3 pr-4 text-slate-600">Data center (SG, NA, or SAU)</td>
                <td className="py-3 font-mono text-slate-800">{config?.region || 'SG'}</td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

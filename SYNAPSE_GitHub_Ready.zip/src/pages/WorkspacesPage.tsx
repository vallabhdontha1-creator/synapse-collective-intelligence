import React, { useEffect, useMemo, useRef, useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import {
  AlertCircle,
  Check,
  Hash,
  LogOut,
  MessageSquare,
  PanelLeft,
  Plus,
  RefreshCw,
  Reply,
  Search,
  Send,
  X,
} from 'lucide-react';
import { useSynapse } from '../context/SynapseContext';
import type { IntelligenceNodeType, SynapseMessage } from '../types/synapse';

const NODE_TYPE_OPTIONS: { value: IntelligenceNodeType; label: string; hint: string }[] = [
  { value: 'observation', label: 'Observation', hint: 'Field note or raw signal' },
  { value: 'hypothesis', label: 'Hypothesis', hint: 'Testable proposition' },
  { value: 'evidence', label: 'Evidence', hint: 'Empirical data or citation' },
  { value: 'decision', label: 'Decision', hint: 'Agreed action or consensus' },
];

const NODE_TEXT_COLORS: Record<IntelligenceNodeType, string> = {
  observation: 'text-slate-600',
  hypothesis: 'text-indigo-700',
  evidence: 'text-emerald-700',
  decision: 'text-amber-700',
};

function formatTime(ts: number): string {
  try {
    return new Intl.DateTimeFormat('en-US', {
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',
      hour12: false,
    }).format(new Date(ts));
  } catch {
    return '';
  }
}

export function WorkspacesPage() {
  const { roomId } = useParams<{ roomId?: string }>();
  const navigate = useNavigate();
  const {
    config,
    connectionState,
    connectionError,
    identity,
    rooms,
    roomsLoading,
    activeRoomId,
    joiningRoom,
    roomError,
    participantCounts,
    roomBriefs,
    messagesByRoom,
    connectSession,
    disconnectSession,
    joinRoom,
    createRoom,
    sendNodeMessage,
    updateRoomBrief,
    clearErrors,
  } = useSynapse();

  const [handleInput, setHandleInput] = useState(identity.userId);
  const [nameInput, setNameInput] = useState(identity.displayName);
  const [mobileDrawerOpen, setMobileDrawerOpen] = useState(false);

  // Room creation state
  const [showCreateRoom, setShowCreateRoom] = useState(false);
  const [newRoomName, setNewRoomName] = useState('');
  const [newRoomDomain, setNewRoomDomain] = useState('');
  const [newRoomDesc, setNewRoomDesc] = useState('');
  const [creatingRoom, setCreatingRoom] = useState(false);

  // Message stream filter & composer state
  const [filterType, setFilterType] = useState<'all' | IntelligenceNodeType>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [composerText, setComposerText] = useState('');
  const [composerNodeType, setComposerNodeType] = useState<IntelligenceNodeType>('observation');
  const [replyingTo, setReplyingTo] = useState<SynapseMessage | null>(null);
  const [sending, setSending] = useState(false);

  // Room brief editor state
  const [editingBrief, setEditingBrief] = useState(false);
  const [briefDraft, setBriefDraft] = useState('');
  const [briefNotice, setBriefNotice] = useState<string | null>(null);

  const feedEndRef = useRef<HTMLDivElement | null>(null);

  const targetRoomId = roomId || activeRoomId || rooms[0]?.channelId || 'synapse-global-commons';
  const currentRoom = useMemo(
    () => rooms.find((r) => r.channelId === targetRoomId) || null,
    [rooms, targetRoomId],
  );

  // Automatically enter the target room once connected
  useEffect(() => {
    if (
      connectionState === 'connected' &&
      targetRoomId &&
      activeRoomId !== targetRoomId &&
      !joiningRoom
    ) {
      joinRoom(targetRoomId);
    }
  }, [connectionState, targetRoomId, activeRoomId, joiningRoom, joinRoom]);

  const rawMessages = messagesByRoom[targetRoomId] || [];

  const filteredMessages = useMemo(() => {
    const q = searchQuery.trim().toLowerCase();
    return rawMessages.filter((m) => {
      if (filterType !== 'all' && m.nodeType !== filterType) return false;
      if (!q) return true;
      return (
        m.text.toLowerCase().includes(q) ||
        m.authorName.toLowerCase().includes(q) ||
        m.senderUserId.toLowerCase().includes(q)
      );
    });
  }, [rawMessages, filterType, searchQuery]);

  useEffect(() => {
    feedEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [filteredMessages.length, targetRoomId]);

  const currentBrief = roomBriefs[targetRoomId] || '';

  async function handleConnectSubmit(e: React.FormEvent) {
    e.preventDefault();
    const ok = await connectSession(handleInput, nameInput);
    if (ok && targetRoomId) {
      await joinRoom(targetRoomId);
    }
  }

  async function handleSelectRoom(channelId: string) {
    setMobileDrawerOpen(false);
    setReplyingTo(null);
    setBriefNotice(null);
    setEditingBrief(false);
    navigate(`/workspaces/${channelId}`);
    if (connectionState === 'connected') {
      await joinRoom(channelId);
    }
  }

  async function handleCreateRoomSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!newRoomName.trim()) return;
    setCreatingRoom(true);
    const slug = newRoomName
      .trim()
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, '-')
      .replace(/^-|-$/g, '')
      .slice(0, 48);
    const channelId = `synapse-${slug || Date.now().toString(36)}`;
    const created = await createRoom({
      channelId,
      name: newRoomName.trim(),
      domain: newRoomDomain.trim() || 'Collective Research',
      description:
        newRoomDesc.trim() ||
        'Collaborative synthesis channel created for real-time team reasoning.',
    });
    setCreatingRoom(false);
    if (created) {
      setNewRoomName('');
      setNewRoomDomain('');
      setNewRoomDesc('');
      setShowCreateRoom(false);
      await handleSelectRoom(created.channelId);
    }
  }

  async function handleSendMessage(e?: React.FormEvent) {
    if (e) e.preventDefault();
    const text = composerText.trim();
    if (!text || sending || connectionState !== 'connected' || activeRoomId !== targetRoomId) {
      return;
    }
    setSending(true);
    const ok = await sendNodeMessage({
      channelId: targetRoomId,
      text,
      nodeType: composerNodeType,
      replyTo: replyingTo
        ? {
            messageId: replyingTo.messageId,
            senderUserId: replyingTo.senderUserId,
            text: replyingTo.text,
          }
        : undefined,
    });
    setSending(false);
    if (ok) {
      setComposerText('');
      setReplyingTo(null);
    }
  }

  async function handleSaveBrief(e: React.FormEvent) {
    e.preventDefault();
    setBriefNotice(null);
    const res = await updateRoomBrief(targetRoomId, briefDraft.trim());
    if (res.ok) {
      setEditingBrief(false);
      setBriefNotice('Shared channel brief updated across Nexconn participants.');
    } else if (res.error) {
      setBriefNotice(res.error);
    }
  }

  const connectionLabel =
    connectionState === 'connected'
      ? 'Connected'
      : connectionState === 'connecting'
        ? 'Connecting'
        : connectionState === 'suspended'
          ? 'Reconnecting'
          : connectionState === 'unconfigured'
            ? 'Credentials Required'
            : connectionState === 'loading-config'
              ? 'Loading'
              : connectionState === 'error'
                ? 'Connection Error'
                : 'Disconnected';

  const connectionTextColor =
    connectionState === 'connected'
      ? 'text-emerald-700'
      : connectionState === 'connecting' || connectionState === 'suspended'
        ? 'text-amber-700'
        : connectionState === 'error' || connectionState === 'unconfigured'
          ? 'text-rose-700'
          : 'text-slate-600';

  const participantCount = participantCounts[targetRoomId];

  const sidebarContent = (
    <div className="flex h-full flex-col">
      <div className="flex items-center justify-between border-b border-slate-200 px-4 py-3.5">
        <h2 className="font-display text-sm font-semibold text-slate-900">
          Collective Rooms
        </h2>
        <button
          type="button"
          onClick={() => setShowCreateRoom((prev) => !prev)}
          className="inline-flex min-h-[36px] items-center gap-1 rounded-md px-2.5 py-1 text-xs font-medium text-indigo-700 hover:bg-indigo-50 focus-visible:outline-2 focus-visible:outline-indigo-600"
        >
          <Plus className="h-3.5 w-3.5" aria-hidden="true" />
          <span>New Room</span>
        </button>
      </div>

      {showCreateRoom && (
        <form
          onSubmit={handleCreateRoomSubmit}
          className="border-b border-slate-200 bg-slate-50 p-4 space-y-2.5"
        >
          <p className="text-xs font-semibold text-slate-900">Provision Open Channel</p>
          <input
            type="text"
            required
            maxLength={60}
            value={newRoomName}
            onChange={(e) => setNewRoomName(e.target.value)}
            placeholder="Room title (e.g. AI Alignment)"
            className="w-full rounded-lg border border-slate-200 bg-white px-3 py-2 text-xs text-slate-900 focus:border-indigo-600 focus:outline-none"
          />
          <input
            type="text"
            maxLength={48}
            value={newRoomDomain}
            onChange={(e) => setNewRoomDomain(e.target.value)}
            placeholder="Domain (optional)"
            className="w-full rounded-lg border border-slate-200 bg-white px-3 py-2 text-xs text-slate-900 focus:border-indigo-600 focus:outline-none"
          />
          <textarea
            rows={2}
            maxLength={200}
            value={newRoomDesc}
            onChange={(e) => setNewRoomDesc(e.target.value)}
            placeholder="Brief research goal..."
            className="w-full rounded-lg border border-slate-200 bg-white px-3 py-2 text-xs text-slate-900 focus:border-indigo-600 focus:outline-none"
          />
          <div className="flex items-center gap-2">
            <button
              type="submit"
              disabled={creatingRoom}
              className="rounded-lg bg-indigo-700 px-3 py-1.5 text-xs font-medium text-white hover:bg-indigo-800 disabled:opacity-60"
            >
              {creatingRoom ? 'Creating...' : 'Create'}
            </button>
            <button
              type="button"
              onClick={() => setShowCreateRoom(false)}
              className="rounded-lg border border-slate-200 bg-white px-3 py-1.5 text-xs font-medium text-slate-700 hover:bg-slate-100"
            >
              Cancel
            </button>
          </div>
        </form>
      )}

      <div className="flex-1 overflow-y-auto divide-y divide-slate-100">
        {roomsLoading ? (
          <div className="space-y-3 p-4">
            {[1, 2, 3].map((n) => (
              <div key={n} className="h-14 animate-pulse rounded-lg bg-slate-100" />
            ))}
          </div>
        ) : (
          rooms.map((room) => {
            const isSelected = room.channelId === targetRoomId;
            const msgCount = (messagesByRoom[room.channelId] || []).length;
            return (
              <button
                key={room.channelId}
                type="button"
                onClick={() => handleSelectRoom(room.channelId)}
                className={`w-full px-4 py-3.5 text-left transition-colors focus-visible:outline-2 focus-visible:outline-inset focus-visible:outline-indigo-600 ${
                  isSelected ? 'bg-indigo-50/70' : 'hover:bg-slate-50'
                }`}
              >
                <div className="flex items-center justify-between gap-2">
                  <span
                    className={`flex items-center gap-1.5 text-sm font-semibold truncate ${
                      isSelected ? 'text-indigo-800' : 'text-slate-900'
                    }`}
                  >
                    <Hash className="h-3.5 w-3.5 shrink-0 text-slate-400" aria-hidden="true" />
                    <span className="truncate">{room.name}</span>
                  </span>
                  {msgCount > 0 && (
                    <span className="font-mono text-xs tabular-nums text-slate-500">
                      {msgCount}
                    </span>
                  )}
                </div>
                <p className="mt-1 text-xs text-slate-500 truncate">{room.domain}</p>
              </button>
            );
          })
        )}
      </div>
    </div>
  );

  return (
    <div className="mx-auto flex w-full max-w-[1360px] flex-1 flex-col px-4 py-6 sm:px-6 lg:px-8">
      {/* Unconfigured Credentials Alert */}
      {connectionState === 'unconfigured' && (
        <div
          role="alert"
          className="mb-5 rounded-xl border border-amber-200 bg-amber-50 p-4 text-sm text-amber-950"
        >
          <div className="flex items-start gap-3">
            <AlertCircle className="mt-0.5 h-5 w-5 shrink-0 text-amber-700" aria-hidden="true" />
            <div>
              <p className="font-semibold">
                Nexconn Server Credentials Required
              </p>
              <p className="mt-1 text-xs leading-relaxed text-amber-900">
                Set <code className="font-mono font-medium">NEXCONN_APP_KEY</code> and{' '}
                <code className="font-mono font-medium">NEXCONN_APP_SECRET</code> (and optional{' '}
                <code className="font-mono font-medium">NEXCONN_REGION</code>) in your server
                environment variables or AI Studio Secrets to enable live real-time token issuance
                and OpenChannel messaging.
              </p>
            </div>
          </div>
        </div>
      )}

      {/* Connection / Room Error Alert */}
      {(connectionError || roomError) && (
        <div
          role="alert"
          className="mb-5 flex items-start justify-between gap-4 rounded-xl border border-rose-200 bg-rose-50 p-4 text-sm text-rose-900"
        >
          <div className="flex items-start gap-3">
            <AlertCircle className="mt-0.5 h-5 w-5 shrink-0 text-rose-700" aria-hidden="true" />
            <div>
              <p className="font-medium">{connectionError || roomError}</p>
            </div>
          </div>
          <button
            type="button"
            onClick={clearErrors}
            aria-label="Dismiss error"
            className="rounded-md p-1 text-rose-700 hover:bg-rose-100"
          >
            <X className="h-4 w-4" />
          </button>
        </div>
      )}

      {/* Session Identity & Nexconn Connection Strip */}
      <div className="mb-5 rounded-xl border border-slate-200 bg-white p-4">
        <div className="flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
          <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-xs text-slate-600">
            <span className={`font-semibold ${connectionTextColor}`}>
              Nexconn Status: {connectionLabel}
            </span>
            <span aria-hidden="true">·</span>
            <span>Region: {config?.region || 'SG'}</span>
            {connectionState === 'connected' && (
              <>
                <span aria-hidden="true">·</span>
                <span className="font-mono text-slate-800">
                  {identity.displayName} (@{identity.userId})
                </span>
              </>
            )}
          </div>

          {connectionState !== 'connected' ? (
            <form
              onSubmit={handleConnectSubmit}
              className="flex flex-col gap-2.5 sm:flex-row sm:items-center"
            >
              <label className="sr-only" htmlFor="synapse-display-name">
                Display Name
              </label>
              <input
                id="synapse-display-name"
                type="text"
                required
                maxLength={64}
                value={nameInput}
                onChange={(e) => setNameInput(e.target.value)}
                placeholder="Display name"
                className="min-h-[40px] rounded-lg border border-slate-200 bg-slate-50 px-3 py-1.5 text-sm text-slate-900 focus:border-indigo-600 focus:bg-white focus:outline-none"
              />
              <label className="sr-only" htmlFor="synapse-handle">
                Participant Handle
              </label>
              <input
                id="synapse-handle"
                type="text"
                required
                maxLength={64}
                value={handleInput}
                onChange={(e) => setHandleInput(e.target.value)}
                placeholder="User ID (e.g. alice_01)"
                className="min-h-[40px] rounded-lg border border-slate-200 bg-slate-50 px-3 py-1.5 font-mono text-xs text-slate-900 focus:border-indigo-600 focus:bg-white focus:outline-none"
              />
              <button
                type="submit"
                disabled={
                  connectionState === 'connecting' ||
                  connectionState === 'unconfigured' ||
                  connectionState === 'loading-config'
                }
                className="inline-flex min-h-[40px] items-center justify-center gap-2 rounded-lg bg-indigo-700 px-4 py-2 text-sm font-medium text-white transition-colors hover:bg-indigo-800 disabled:cursor-not-allowed disabled:opacity-50 whitespace-nowrap shrink-0"
              >
                {connectionState === 'connecting' ? (
                  <>
                    <RefreshCw className="h-4 w-4 animate-spin" aria-hidden="true" />
                    <span>Connecting...</span>
                  </>
                ) : (
                  <span>Connect Session</span>
                )}
              </button>
            </form>
          ) : (
            <div className="flex items-center gap-3">
              <button
                type="button"
                onClick={() => joinRoom(targetRoomId)}
                disabled={joiningRoom}
                className="inline-flex min-h-[40px] items-center gap-1.5 rounded-lg border border-slate-200 bg-white px-3.5 py-2 text-xs font-medium text-slate-700 hover:bg-slate-50 whitespace-nowrap"
              >
                <RefreshCw className={`h-3.5 w-3.5 ${joiningRoom ? 'animate-spin' : ''}`} />
                <span>Sync Room</span>
              </button>
              <button
                type="button"
                onClick={disconnectSession}
                className="inline-flex min-h-[40px] items-center gap-1.5 rounded-lg border border-slate-200 bg-white px-3.5 py-2 text-xs font-medium text-slate-700 hover:bg-slate-50 whitespace-nowrap"
              >
                <LogOut className="h-3.5 w-3.5" aria-hidden="true" />
                <span>Disconnect</span>
              </button>
            </div>
          )}
        </div>
      </div>

      {/* Main 2-Column Workspace */}
      <div className="grid min-h-[580px] flex-1 grid-cols-1 overflow-hidden rounded-xl border border-slate-200 bg-white lg:grid-cols-12">
        {/* Desktop Sidebar */}
        <aside className="hidden border-r border-slate-200 lg:col-span-3 lg:block">
          {sidebarContent}
        </aside>

        {/* Mobile Rooms Drawer */}
        {mobileDrawerOpen && (
          <div className="fixed inset-0 z-50 flex lg:hidden">
            <div
              className="fixed inset-0 bg-slate-900/40"
              onClick={() => setMobileDrawerOpen(false)}
              aria-hidden="true"
            />
            <div className="relative z-10 flex h-full w-80 max-w-[85vw] flex-col bg-white shadow-xl">
              <div className="flex items-center justify-between border-b border-slate-200 px-4 py-3">
                <span className="font-display text-sm font-semibold text-slate-900">
                  Switch Channel
                </span>
                <button
                  type="button"
                  onClick={() => setMobileDrawerOpen(false)}
                  className="p-2 text-slate-600 hover:text-slate-900"
                  aria-label="Close rooms drawer"
                >
                  <X className="h-4 w-4" />
                </button>
              </div>
              <div className="flex-1 overflow-y-auto">{sidebarContent}</div>
            </div>
          </div>
        )}

        {/* Active Channel Stream */}
        <section className="flex flex-col lg:col-span-9">
          {/* Channel Header */}
          <div className="border-b border-slate-200 px-4 py-4 sm:px-6">
            <div className="flex flex-wrap items-start justify-between gap-4">
              <div className="flex items-start gap-3">
                <button
                  type="button"
                  onClick={() => setMobileDrawerOpen(true)}
                  className="mt-0.5 inline-flex h-10 w-10 items-center justify-center rounded-lg border border-slate-200 text-slate-700 hover:bg-slate-50 lg:hidden"
                  aria-label="Open rooms list"
                >
                  <PanelLeft className="h-4 w-4" />
                </button>
                <div>
                  <h1 className="font-display text-lg font-bold text-slate-900">
                    {currentRoom?.name || targetRoomId}
                  </h1>
                  <div className="mt-1 flex flex-wrap items-center gap-x-2.5 gap-y-1 text-xs text-slate-500">
                    <span>{currentRoom?.domain || 'Open Channel'}</span>
                    <span aria-hidden="true">·</span>
                    <span className="font-mono">{targetRoomId}</span>
                    {typeof participantCount === 'number' && (
                      <>
                        <span aria-hidden="true">·</span>
                        <span className="font-mono tabular-nums text-slate-700">
                          {participantCount} {participantCount === 1 ? 'participant' : 'participants'}
                        </span>
                      </>
                    )}
                  </div>
                </div>
              </div>

              <button
                type="button"
                onClick={() => {
                  setBriefDraft(currentBrief);
                  setEditingBrief((prev) => !prev);
                }}
                disabled={connectionState !== 'connected'}
                className="min-h-[36px] rounded-lg border border-slate-200 bg-white px-3 py-1.5 text-xs font-medium text-slate-700 hover:bg-slate-50 disabled:opacity-50 whitespace-nowrap"
              >
                {editingBrief ? 'Close Brief' : 'Shared Room Brief'}
              </button>
            </div>

            {/* Shared Room Brief (Nexconn OpenChannel KV Metadata) */}
            {(currentBrief || editingBrief || briefNotice) && (
              <div className="mt-3 rounded-lg border border-slate-200 bg-slate-50 p-3">
                {editingBrief ? (
                  <form onSubmit={handleSaveBrief} className="space-y-2">
                    <label
                      htmlFor="room-brief-input"
                      className="block text-xs font-medium text-slate-700"
                    >
                      Pinned Collective Synthesis Brief (synced via Nexconn OpenChannel metadata)
                    </label>
                    <textarea
                      id="room-brief-input"
                      rows={2}
                      maxLength={800}
                      value={briefDraft}
                      onChange={(e) => setBriefDraft(e.target.value)}
                      placeholder="Summarize current group consensus or open questions..."
                      className="w-full rounded-lg border border-slate-200 bg-white px-3 py-2 text-xs text-slate-900 focus:border-indigo-600 focus:outline-none"
                    />
                    <div className="flex items-center gap-2">
                      <button
                        type="submit"
                        className="inline-flex items-center gap-1 rounded-md bg-indigo-700 px-3 py-1.5 text-xs font-medium text-white hover:bg-indigo-800"
                      >
                        <Check className="h-3.5 w-3.5" />
                        <span>Save Brief</span>
                      </button>
                      <button
                        type="button"
                        onClick={() => setEditingBrief(false)}
                        className="rounded-md border border-slate-200 bg-white px-3 py-1.5 text-xs font-medium text-slate-700 hover:bg-slate-100"
                      >
                        Cancel
                      </button>
                    </div>
                  </form>
                ) : (
                  <p className="text-xs leading-relaxed text-slate-700">
                    <strong className="font-semibold text-slate-900">Room Brief: </strong>
                    {currentBrief}
                  </p>
                )}
                {briefNotice && <p className="mt-1.5 text-xs text-slate-600">{briefNotice}</p>}
              </div>
            )}

            {/* Filter & Search Toolbar */}
            <div className="mt-4 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
              <div
                className="flex flex-wrap items-center gap-1 rounded-lg bg-slate-100 p-1"
                role="tablist"
                aria-label="Filter messages by reasoning node type"
              >
                <button
                  type="button"
                  onClick={() => setFilterType('all')}
                  className={`rounded-md px-2.5 py-1 text-xs font-medium transition-colors whitespace-nowrap ${
                    filterType === 'all'
                      ? 'bg-white text-slate-900 shadow-xs'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  All
                </button>
                {NODE_TYPE_OPTIONS.map((opt) => (
                  <button
                    key={opt.value}
                    type="button"
                    onClick={() => setFilterType(opt.value)}
                    className={`rounded-md px-2.5 py-1 text-xs font-medium transition-colors whitespace-nowrap ${
                      filterType === opt.value
                        ? 'bg-white text-slate-900 shadow-xs'
                        : 'text-slate-600 hover:text-slate-900'
                    }`}
                  >
                    {opt.label}
                  </button>
                ))}
              </div>

              <div className="relative w-full sm:w-60">
                <Search
                  className="pointer-events-none absolute left-3 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-slate-400"
                  aria-hidden="true"
                />
                <input
                  type="search"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Filter stream..."
                  aria-label="Filter channel messages"
                  className="w-full rounded-lg border border-slate-200 bg-slate-50 py-1.5 pl-8 pr-3 text-xs text-slate-900 focus:border-indigo-600 focus:bg-white focus:outline-none"
                />
              </div>
            </div>
          </div>

          {/* Message Feed */}
          <div className="flex-1 overflow-y-auto px-4 py-5 sm:px-6">
            {joiningRoom ? (
              <div className="space-y-4">
                {[1, 2, 3].map((item) => (
                  <div
                    key={item}
                    className="h-20 animate-pulse rounded-xl border border-slate-100 bg-slate-50"
                  />
                ))}
              </div>
            ) : connectionState !== 'connected' ? (
              <div className="flex h-full min-h-[280px] flex-col items-center justify-center text-center">
                <MessageSquare className="h-9 w-9 text-slate-300" aria-hidden="true" />
                <h2 className="mt-3 font-display text-base font-semibold text-slate-900">
                  Connect to enter {currentRoom?.name || targetRoomId}
                </h2>
                <p className="mt-1.5 max-w-md text-sm text-slate-600">
                  Use the session bar above to issue a server-signed Nexconn token and join this
                  collaborative OpenChannel in real time.
                </p>
              </div>
            ) : filteredMessages.length === 0 ? (
              <div className="flex h-full min-h-[280px] flex-col items-center justify-center text-center">
                <MessageSquare className="h-9 w-9 text-slate-300" aria-hidden="true" />
                <h2 className="mt-3 font-display text-base font-semibold text-slate-900">
                  {rawMessages.length === 0
                    ? 'Channel ready for first contribution'
                    : 'No matching nodes in current filter'}
                </h2>
                <p className="mt-1.5 max-w-md text-sm text-slate-600">
                  {rawMessages.length === 0
                    ? 'Post an Observation, Hypothesis, Evidence citation, or Decision below. All connected participants in this room receive updates live.'
                    : 'Adjust your search query or node filter to view all channel messages.'}
                </p>
              </div>
            ) : (
              <div className="divide-y divide-slate-100">
                {filteredMessages.map((msg) => {
                  const isOwn = msg.senderUserId === identity.userId;
                  return (
                    <article key={msg.messageId} className="py-4 first:pt-0 last:pb-0">
                      <div className="flex items-center justify-between gap-4">
                        <div className="flex flex-wrap items-center gap-x-2.5 gap-y-1 text-xs">
                          <span className="font-semibold text-slate-900">{msg.authorName}</span>
                          <span className="font-mono text-slate-400">@{msg.senderUserId}</span>
                          {isOwn && <span className="text-slate-400">(you)</span>}
                          <span aria-hidden="true" className="text-slate-300">
                            ·
                          </span>
                          <span className={`font-medium capitalize ${NODE_TEXT_COLORS[msg.nodeType]}`}>
                            {msg.nodeType}
                          </span>
                          <span aria-hidden="true" className="text-slate-300">
                            ·
                          </span>
                          <time className="font-mono tabular-nums text-slate-400">
                            {formatTime(msg.sentTime)}
                          </time>
                        </div>

                        <button
                          type="button"
                          onClick={() => setReplyingTo(msg)}
                          className="inline-flex items-center gap-1 rounded-md px-2 py-1 text-xs text-slate-500 hover:bg-slate-100 hover:text-slate-800"
                          title="Quote & reply to this node"
                        >
                          <Reply className="h-3.5 w-3.5" aria-hidden="true" />
                          <span>Reply</span>
                        </button>
                      </div>

                      {msg.replyTo && (
                        <div className="mt-2 rounded-lg border border-slate-200 bg-slate-50 px-3 py-2 text-xs text-slate-600">
                          <span className="font-medium text-slate-800">
                            Replying to @{msg.replyTo.senderUserId}:{' '}
                          </span>
                          <span className="line-clamp-2">{msg.replyTo.text}</span>
                        </div>
                      )}

                      <p className="mt-2 whitespace-pre-wrap text-sm leading-relaxed text-slate-800">
                        {msg.text}
                      </p>
                    </article>
                  );
                })}
                <div ref={feedEndRef} />
              </div>
            )}
          </div>

          {/* Composer */}
          <form
            onSubmit={handleSendMessage}
            className="border-t border-slate-200 bg-slate-50/70 p-4 sm:px-6"
          >
            {replyingTo && (
              <div className="mb-3 flex items-center justify-between gap-3 rounded-lg border border-slate-200 bg-white px-3 py-2 text-xs text-slate-600">
                <div className="truncate">
                  <span className="font-semibold text-slate-900">
                    Replying to {replyingTo.authorName}:{' '}
                  </span>
                  <span>{replyingTo.text}</span>
                </div>
                <button
                  type="button"
                  onClick={() => setReplyingTo(null)}
                  className="text-slate-500 hover:text-slate-800"
                  aria-label="Cancel reply"
                >
                  <X className="h-3.5 w-3.5" />
                </button>
              </div>
            )}

            <div className="mb-2.5 flex flex-wrap items-center justify-between gap-2">
              <div className="flex flex-wrap items-center gap-1 rounded-lg bg-slate-200/70 p-1">
                {NODE_TYPE_OPTIONS.map((opt) => (
                  <button
                    key={opt.value}
                    type="button"
                    onClick={() => setComposerNodeType(opt.value)}
                    title={opt.hint}
                    className={`rounded-md px-2.5 py-1 text-xs font-medium transition-colors whitespace-nowrap ${
                      composerNodeType === opt.value
                        ? 'bg-white text-indigo-800 shadow-xs'
                        : 'text-slate-600 hover:text-slate-900'
                    }`}
                  >
                    {opt.label}
                  </button>
                ))}
              </div>
              <span className="text-xs text-slate-500">
                {NODE_TYPE_OPTIONS.find((o) => o.value === composerNodeType)?.hint}
              </span>
            </div>

            <div className="flex items-end gap-3">
              <label htmlFor="synapse-composer" className="sr-only">
                Contribute to room
              </label>
              <textarea
                id="synapse-composer"
                rows={2}
                value={composerText}
                onChange={(e) => setComposerText(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter' && !e.shiftKey) {
                    e.preventDefault();
                    handleSendMessage();
                  }
                }}
                disabled={connectionState !== 'connected' || activeRoomId !== targetRoomId}
                placeholder={
                  connectionState === 'connected'
                    ? `Add a structured ${composerNodeType} to ${currentRoom?.name || targetRoomId}...`
                    : 'Connect above to send real-time messages...'
                }
                className="flex-1 resize-none rounded-lg border border-slate-200 bg-white px-3.5 py-2.5 text-sm text-slate-900 focus:border-indigo-600 focus:outline-none disabled:bg-slate-100 disabled:text-slate-400"
              />
              <button
                type="submit"
                disabled={
                  sending ||
                  !composerText.trim() ||
                  connectionState !== 'connected' ||
                  activeRoomId !== targetRoomId
                }
                className="inline-flex min-h-[44px] items-center gap-2 rounded-lg bg-indigo-700 px-4 py-2.5 text-sm font-medium text-white transition-colors hover:bg-indigo-800 disabled:cursor-not-allowed disabled:opacity-50 whitespace-nowrap shrink-0"
              >
                <Send className="h-4 w-4" aria-hidden="true" />
                <span>{sending ? 'Sending...' : 'Transmit'}</span>
              </button>
            </div>
          </form>
        </section>
      </div>
    </div>
  );
}

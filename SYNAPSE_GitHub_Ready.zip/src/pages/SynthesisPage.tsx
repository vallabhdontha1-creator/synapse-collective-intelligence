import { useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight, Download, Layers } from 'lucide-react';
import { useSynapse } from '../context/SynapseContext';
import type { IntelligenceNodeType, SynapseMessage } from '../types/synapse';

const TYPE_FILTERS: { id: 'all' | IntelligenceNodeType; label: string }[] = [
  { id: 'all', label: 'All Nodes' },
  { id: 'decision', label: 'Decisions' },
  { id: 'hypothesis', label: 'Hypotheses' },
  { id: 'evidence', label: 'Evidence' },
  { id: 'observation', label: 'Observations' },
];

export function SynthesisPage() {
  const { rooms, messagesByRoom, roomBriefs } = useSynapse();
  const [selectedRoom, setSelectedRoom] = useState<string>('all');
  const [selectedType, setSelectedType] = useState<'all' | IntelligenceNodeType>('all');

  const allEntries = useMemo(() => {
    const collected: Array<SynapseMessage & { roomName: string }> = [];
    for (const [channelId, msgs] of Object.entries(messagesByRoom)) {
      const room = rooms.find((r) => r.channelId === channelId);
      const roomName = room?.name || channelId;
      for (const msg of msgs) {
        collected.push({ ...msg, roomName });
      }
    }
    return collected.sort((a, b) => b.sentTime - a.sentTime);
  }, [messagesByRoom, rooms]);

  const filteredEntries = useMemo(() => {
    return allEntries.filter((entry) => {
      if (selectedRoom !== 'all' && entry.channelId !== selectedRoom) return false;
      if (selectedType !== 'all' && entry.nodeType !== selectedType) return false;
      return true;
    });
  }, [allEntries, selectedRoom, selectedType]);

  const counts = useMemo(() => {
    const result: Record<IntelligenceNodeType, number> = {
      decision: 0,
      hypothesis: 0,
      evidence: 0,
      observation: 0,
    };
    for (const item of allEntries) {
      result[item.nodeType] += 1;
    }
    return result;
  }, [allEntries]);

  function handleExportMarkdown() {
    const lines: string[] = [
      '# SYNAPSE Collective Intelligence Synthesis Brief',
      `Exported: ${new Date().toISOString()}`,
      '',
    ];

    for (const room of rooms) {
      const msgs = messagesByRoom[room.channelId] || [];
      const brief = roomBriefs[room.channelId];
      if (msgs.length === 0 && !brief) continue;

      lines.push(`## ${room.name} (${room.channelId})`);
      if (brief) {
        lines.push(`> **Shared Room Brief:** ${brief}`);
        lines.push('');
      }
      for (const m of msgs) {
        lines.push(
          `- **[${m.nodeType.toUpperCase()}]** ${m.authorName} (@${m.senderUserId}): ${m.text}`,
        );
      }
      lines.push('');
    }

    const blob = new Blob([lines.join('\n')], { type: 'text/markdown;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `synapse-synthesis-${new Date().toISOString().slice(0, 10)}.md`;
    document.body.appendChild(link);
    link.click();
    link.remove();
    URL.revokeObjectURL(url);
  }

  return (
    <div className="mx-auto w-full max-w-[1360px] flex-1 px-4 py-10 sm:px-6 lg:px-8">
      <div className="flex flex-col gap-4 border-b border-slate-200 pb-6 sm:flex-row sm:items-end sm:justify-between">
        <div>
          <h1 className="font-display text-3xl font-bold tracking-tight text-slate-900">
            Synthesis Ledger
          </h1>
          <p className="mt-2 max-w-2xl text-sm text-slate-600">
            Structured index of Observations, Hypotheses, Evidence, and Consensus Decisions
            captured across your active Nexconn OpenChannel sessions.
          </p>
        </div>

        <button
          type="button"
          onClick={handleExportMarkdown}
          disabled={allEntries.length === 0}
          className="inline-flex min-h-[42px] items-center gap-2 rounded-lg bg-indigo-700 px-4 py-2 text-sm font-medium text-white transition-colors hover:bg-indigo-800 disabled:cursor-not-allowed disabled:opacity-50 whitespace-nowrap shrink-0"
        >
          <Download className="h-4 w-4" aria-hidden="true" />
          <span>Export Markdown Brief</span>
        </button>
      </div>

      {/* Tabular Summary Strip */}
      <div className="mt-6 grid grid-cols-2 gap-4 sm:grid-cols-4">
        <div className="rounded-xl border border-slate-200 bg-white p-4">
          <p className="text-xs text-slate-500">Decisions</p>
          <p className="mt-1 font-mono text-2xl font-semibold tabular-nums text-slate-900">
            {counts.decision}
          </p>
        </div>
        <div className="rounded-xl border border-slate-200 bg-white p-4">
          <p className="text-xs text-slate-500">Hypotheses</p>
          <p className="mt-1 font-mono text-2xl font-semibold tabular-nums text-slate-900">
            {counts.hypothesis}
          </p>
        </div>
        <div className="rounded-xl border border-slate-200 bg-white p-4">
          <p className="text-xs text-slate-500">Evidence</p>
          <p className="mt-1 font-mono text-2xl font-semibold tabular-nums text-slate-900">
            {counts.evidence}
          </p>
        </div>
        <div className="rounded-xl border border-slate-200 bg-white p-4">
          <p className="text-xs text-slate-500">Observations</p>
          <p className="mt-1 font-mono text-2xl font-semibold tabular-nums text-slate-900">
            {counts.observation}
          </p>
        </div>
      </div>

      {/* Filters */}
      <div className="mt-6 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div className="flex flex-wrap items-center gap-1 rounded-lg bg-slate-200/70 p-1">
          {TYPE_FILTERS.map((item) => (
            <button
              key={item.id}
              type="button"
              onClick={() => setSelectedType(item.id)}
              className={`rounded-md px-3 py-1.5 text-xs font-medium transition-colors whitespace-nowrap ${
                selectedType === item.id
                  ? 'bg-white text-slate-900 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              {item.label}
            </button>
          ))}
        </div>

        <select
          aria-label="Filter synthesis by room"
          value={selectedRoom}
          onChange={(e) => setSelectedRoom(e.target.value)}
          className="min-h-[38px] rounded-lg border border-slate-200 bg-white px-3 py-1.5 text-xs font-medium text-slate-700 focus:border-indigo-600 focus:outline-none"
        >
          <option value="all">All Channels</option>
          {rooms.map((room) => (
            <option key={room.channelId} value={room.channelId}>
              {room.name}
            </option>
          ))}
        </select>
      </div>

      {/* Ledger List */}
      <div className="mt-6 rounded-xl border border-slate-200 bg-white">
        {filteredEntries.length === 0 ? (
          <div className="flex flex-col items-center justify-center px-6 py-16 text-center">
            <Layers className="h-9 w-9 text-slate-300" aria-hidden="true" />
            <h2 className="mt-3 font-display text-base font-semibold text-slate-900">
              No synthesis nodes captured in this session yet
            </h2>
            <p className="mt-1.5 max-w-md text-sm text-slate-600">
              Connect to a collaborative room and transmit Observations, Hypotheses, Evidence, or
              Decisions to populate this ledger automatically.
            </p>
            <Link
              to="/workspaces"
              className="mt-5 inline-flex items-center gap-1.5 rounded-lg bg-indigo-700 px-4 py-2 text-sm font-medium text-white hover:bg-indigo-800"
            >
              <span>Go to Workspaces</span>
              <ArrowRight className="h-4 w-4" />
            </Link>
          </div>
        ) : (
          <div className="divide-y divide-slate-100">
            {filteredEntries.map((item) => (
              <div key={item.messageId} className="p-5">
                <div className="flex flex-wrap items-center justify-between gap-3 text-xs text-slate-500">
                  <div className="flex flex-wrap items-center gap-2">
                    <span className="font-semibold capitalize text-indigo-700">
                      {item.nodeType}
                    </span>
                    <span aria-hidden="true">·</span>
                    <span className="font-medium text-slate-900">{item.roomName}</span>
                    <span aria-hidden="true">·</span>
                    <span>{item.authorName}</span>
                  </div>
                  <Link
                    to={`/workspaces/${item.channelId}`}
                    className="font-medium text-indigo-700 hover:text-indigo-800"
                  >
                    Open in Room
                  </Link>
                </div>
                <p className="mt-2 text-sm leading-relaxed text-slate-800">{item.text}</p>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

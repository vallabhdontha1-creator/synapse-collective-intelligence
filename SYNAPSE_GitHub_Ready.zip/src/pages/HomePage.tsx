import { useState } from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight, Layers, ShieldCheck, Users } from 'lucide-react';
import { useSynapse } from '../context/SynapseContext';

export function HomePage() {
  const { rooms, roomsLoading, config, connectionState } = useSynapse();
  const [heroImgFailed, setHeroImgFailed] = useState(false);
  const [gridImgFailed, setGridImgFailed] = useState(false);

  return (
    <div className="bg-slate-50">
      {/* Hero Split */}
      <section className="border-b border-slate-200 bg-white">
        <div className="mx-auto grid max-w-[1360px] grid-cols-1 items-stretch gap-10 px-4 py-12 sm:px-6 lg:grid-cols-12 lg:gap-12 lg:px-8 lg:py-16">
          <div className="flex flex-col justify-center lg:col-span-6">
            <p className="text-sm font-medium text-indigo-700">
              Collective Intelligence Network · Nexconn Hackathon
            </p>
            <h1 className="mt-3 font-display text-4xl font-bold tracking-tight text-slate-900 sm:text-5xl [text-wrap:balance]">
              Turn scattered group discussions into structured collective knowledge.
            </h1>
            <p className="mt-5 max-w-xl text-base leading-relaxed text-slate-600">
              SYNAPSE connects researchers, engineers, and civic analysts inside real-time
              Nexconn Open Channels where every contribution is classified as an Observation,
              Hypothesis, Evidence, or Decision.
            </p>

            <div className="mt-8 flex flex-wrap items-center gap-4">
              <Link
                to="/workspaces"
                className="inline-flex min-h-[44px] items-center gap-2 rounded-lg bg-indigo-700 px-5 py-2.5 text-sm font-medium text-white transition-colors hover:bg-indigo-800 whitespace-nowrap focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-indigo-700"
              >
                <span>Open Live Workspaces</span>
                <ArrowRight className="h-4 w-4" aria-hidden="true" />
              </Link>
              <Link
                to="/architecture"
                className="inline-flex min-h-[44px] items-center rounded-lg border border-slate-200 bg-white px-5 py-2.5 text-sm font-medium text-slate-700 transition-colors hover:bg-slate-50 whitespace-nowrap focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-slate-400"
              >
                Inspect SDK Architecture
              </Link>
            </div>

            {/* Clean unboxed summary metadata */}
            <div className="mt-8 flex flex-wrap items-center gap-x-4 gap-y-2 border-t border-slate-200 pt-5 text-xs text-slate-500">
              <span className="font-mono tabular-nums text-slate-700">
                {rooms.length} Active Channels
              </span>
              <span aria-hidden="true">·</span>
              <span>Nexconn OpenChannel Protocol</span>
              <span aria-hidden="true">·</span>
              <span>
                Server Status:{' '}
                <strong className="font-medium text-slate-800">
                  {config?.configured
                    ? `Configured (${config.region})`
                    : connectionState === 'loading-config'
                      ? 'Checking'
                      : 'Awaiting Credentials'}
                </strong>
              </span>
            </div>
          </div>

          <div className="lg:col-span-6">
            <div className="h-full min-h-[280px] overflow-hidden rounded-xl border border-slate-200 bg-slate-100">
              {!heroImgFailed ? (
                <img
                  src="/src/assets/images/synapse_network_hero_1795317660273.jpg"
                  alt="Geometric architectural diagram of interconnected collective intelligence nodes"
                  referrerPolicy="no-referrer"
                  onError={() => setHeroImgFailed(true)}
                  className="h-full w-full object-cover"
                />
              ) : (
                <div className="flex h-full min-h-[280px] flex-col items-center justify-center bg-gradient-to-br from-slate-100 to-indigo-50 p-8 text-center">
                  <Layers className="h-10 w-10 text-indigo-700" aria-hidden="true" />
                  <p className="mt-3 font-display text-base font-semibold text-slate-900">
                    Distributed Epistemic Graph
                  </p>
                  <p className="mt-1 text-xs text-slate-600">
                    Real-time participant channels synchronized via Nexconn
                  </p>
                </div>
              )}
            </div>
          </div>
        </div>
      </section>

      {/* Active Collective Intelligence Rooms */}
      <section className="mx-auto max-w-[1360px] px-4 py-14 sm:px-6 lg:px-8">
        <div className="flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between">
          <div>
            <h2 className="font-display text-2xl font-bold tracking-tight text-slate-900">
              Collaborative Channels
            </h2>
            <p className="mt-1 text-sm text-slate-600">
              Select a domain room to join live discussion and contribute structured reasoning nodes.
            </p>
          </div>
          <Link
            to="/workspaces"
            className="text-sm font-medium text-indigo-700 hover:text-indigo-800 whitespace-nowrap"
          >
            Create or manage rooms
          </Link>
        </div>

        {roomsLoading ? (
          <div className="mt-6 grid grid-cols-1 gap-5 md:grid-cols-2">
            {[1, 2, 3, 4].map((idx) => (
              <div
                key={idx}
                className="h-36 animate-pulse rounded-xl border border-slate-200 bg-white p-6"
              />
            ))}
          </div>
        ) : (
          <div className="mt-6 grid grid-cols-1 gap-5 md:grid-cols-2">
            {rooms.map((room) => (
              <Link
                key={room.channelId}
                to={`/workspaces/${room.channelId}`}
                className="group flex flex-col justify-between rounded-xl border border-slate-200 bg-white p-6 transition-colors hover:border-indigo-300 focus-visible:outline-2 focus-visible:outline-indigo-600"
              >
                <div>
                  <div className="flex items-center justify-between gap-4 text-xs text-slate-500">
                    <span>{room.domain}</span>
                    <span className="font-mono text-slate-400">{room.channelId}</span>
                  </div>
                  <h3 className="mt-2 font-display text-lg font-semibold text-slate-900 group-hover:text-indigo-700 transition-colors">
                    {room.name}
                  </h3>
                  <p className="mt-2 text-sm leading-relaxed text-slate-600">{room.description}</p>
                </div>

                <div className="mt-5 flex items-center justify-between border-t border-slate-100 pt-3.5 text-xs font-medium text-indigo-700">
                  <span>Join Open Channel</span>
                  <ArrowRight className="h-3.5 w-3.5 transition-transform group-hover:translate-x-0.5" />
                </div>
              </Link>
            ))}
          </div>
        )}
      </section>

      {/* Problem & Solution + Visual Anchor */}
      <section className="border-t border-slate-200 bg-white">
        <div className="mx-auto grid max-w-[1360px] grid-cols-1 items-stretch gap-10 px-4 py-14 sm:px-6 lg:grid-cols-12 lg:px-8">
          <div className="lg:col-span-5">
            <div className="h-full min-h-[240px] overflow-hidden rounded-xl border border-slate-200 bg-slate-100">
              {!gridImgFailed ? (
                <img
                  src="/src/assets/images/synapse_synthesis_grid_1795317660022.jpg"
                  alt="Structured white index cards linked by blue threads representing synthesis workflows"
                  referrerPolicy="no-referrer"
                  onError={() => setGridImgFailed(true)}
                  className="h-full w-full object-cover"
                />
              ) : (
                <div className="flex h-full min-h-[240px] items-center justify-center bg-slate-100 p-8 text-sm text-slate-600">
                  Structured Synthesis Ledger
                </div>
              )}
            </div>
          </div>

          <div className="flex flex-col justify-center lg:col-span-7">
            <h2 className="font-display text-2xl font-bold tracking-tight text-slate-900">
              Designed for epistemic clarity under real-time velocity
            </h2>
            <p className="mt-3 text-sm leading-relaxed text-slate-600">
              Traditional group chats bury critical hypotheses and empirical citations inside linear
              message streams. SYNAPSE preserves the immediacy of Nexconn Open Channels while giving
              every team a shared taxonomy and live synthesis ledger.
            </p>

            <div className="mt-8 grid grid-cols-1 gap-6 border-t border-slate-200 pt-6 sm:grid-cols-3">
              <div>
                <div className="flex items-center gap-2 text-sm font-semibold text-slate-900">
                  <Users className="h-4 w-4 text-indigo-700" aria-hidden="true" />
                  <span>Multi-Participant Rooms</span>
                </div>
                <p className="mt-1.5 text-xs leading-relaxed text-slate-600">
                  Powered by Nexconn OpenChannel with live participant tracking and history queries.
                </p>
              </div>
              <div>
                <div className="flex items-center gap-2 text-sm font-semibold text-slate-900">
                  <Layers className="h-4 w-4 text-indigo-700" aria-hidden="true" />
                  <span>Typed Reasoning Nodes</span>
                </div>
                <p className="mt-1.5 text-xs leading-relaxed text-slate-600">
                  Tag messages as Observations, Hypotheses, Evidence, or Decisions with threaded quotes.
                </p>
              </div>
              <div>
                <div className="flex items-center gap-2 text-sm font-semibold text-slate-900">
                  <ShieldCheck className="h-4 w-4 text-indigo-700" aria-hidden="true" />
                  <span>Server-Signed Auth</span>
                </div>
                <p className="mt-1.5 text-xs leading-relaxed text-slate-600">
                  App Secret remains isolated on the backend for SHA-1 token issuance and failover.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}

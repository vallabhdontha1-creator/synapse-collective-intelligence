export type IntelligenceNodeType = 'observation' | 'hypothesis' | 'evidence' | 'decision';

export type NexconnRegion = 'SG' | 'NA' | 'SAU';

export type NexconnConnectionState =
  | 'loading-config'
  | 'unconfigured'
  | 'idle'
  | 'connecting'
  | 'connected'
  | 'suspended'
  | 'disconnected'
  | 'error';

export interface NexconnPublicConfig {
  configured: boolean;
  appKey: string;
  region: NexconnRegion;
  missing: string[];
}

export interface SynapseRoom {
  channelId: string;
  name: string;
  domain: string;
  description: string;
  isCurated: boolean;
  createdAt: string;
}

export interface SynapseMessageReply {
  messageId: string;
  senderUserId: string;
  text: string;
}

export interface SynapseMessage {
  messageId: string;
  channelId: string;
  senderUserId: string;
  authorName: string;
  nodeType: IntelligenceNodeType;
  text: string;
  sentTime: number;
  replyTo?: SynapseMessageReply;
}

import { BrowserRouter, Route, Routes } from 'react-router-dom';
import { ErrorBoundary } from './components/ErrorBoundary';
import { Footer } from './components/Footer';
import { TopNav } from './components/TopNav';
import { SynapseProvider } from './context/SynapseContext';
import { ArchitecturePage } from './pages/ArchitecturePage';
import { HomePage } from './pages/HomePage';
import { NotFoundPage } from './pages/NotFoundPage';
import { SynthesisPage } from './pages/SynthesisPage';
import { WorkspacesPage } from './pages/WorkspacesPage';

export default function App() {
  return (
    <ErrorBoundary>
      <BrowserRouter>
        <SynapseProvider>
          <div className="flex min-h-screen flex-col bg-slate-50 text-slate-900">
            <TopNav />
            <main className="flex flex-1 flex-col">
              <Routes>
                <Route path="/" element={<HomePage />} />
                <Route path="/workspaces" element={<WorkspacesPage />} />
                <Route path="/workspaces/:roomId" element={<WorkspacesPage />} />
                <Route path="/synthesis" element={<SynthesisPage />} />
                <Route path="/architecture" element={<ArchitecturePage />} />
                <Route path="*" element={<NotFoundPage />} />
              </Routes>
            </main>
            <Footer />
          </div>
        </SynapseProvider>
      </BrowserRouter>
    </ErrorBoundary>
  );
}

import { Link } from 'react-router-dom';

export function Footer() {
  return (
    <footer className="border-t border-slate-200 bg-white">
      <div className="mx-auto flex max-w-[1360px] flex-col gap-4 px-4 py-8 sm:flex-row sm:items-center sm:justify-between sm:px-6 lg:px-8">
        <div className="text-sm text-slate-600">
          <span className="font-display font-semibold text-slate-900">SYNAPSE</span>
          <span className="mx-2 text-slate-300" aria-hidden="true">
            ·
          </span>
          <span>Collective Intelligence Network for the Nexconn Hackathon</span>
        </div>

        <nav className="flex flex-wrap items-center gap-6 text-sm text-slate-600" aria-label="Footer Navigation">
          <Link to="/workspaces" className="hover:text-slate-900 transition-colors whitespace-nowrap">
            Workspaces
          </Link>
          <Link to="/synthesis" className="hover:text-slate-900 transition-colors whitespace-nowrap">
            Synthesis Ledger
          </Link>
          <Link to="/architecture" className="hover:text-slate-900 transition-colors whitespace-nowrap">
            SDK Architecture
          </Link>
          <a
            href="https://docs.nexconn.ai/"
            target="_blank"
            rel="noopener noreferrer"
            className="hover:text-slate-900 transition-colors whitespace-nowrap"
          >
            Nexconn Docs
          </a>
        </nav>
      </div>
    </footer>
  );
}

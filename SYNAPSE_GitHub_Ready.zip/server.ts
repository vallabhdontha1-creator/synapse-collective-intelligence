import 'dotenv/config';
import express from 'express';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import {
  checkRateLimit,
  ensureOpenChannelRoom,
  getPublicNexconnConfig,
  issueNexconnUserToken,
  listRooms,
} from './server/nexconnService.ts';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const PORT = Number(process.env.PORT || 3000);
const isProduction = process.env.NODE_ENV === 'production';

async function startServer() {
  const app = express();
  app.disable('x-powered-by');
  app.set('trust proxy', 1);

  // Baseline security headers
  app.use((_req, res, next) => {
    res.setHeader('X-Content-Type-Options', 'nosniff');
    res.setHeader('Referrer-Policy', 'strict-origin-when-cross-origin');
    res.setHeader('Permissions-Policy', 'camera=(), microphone=(), geolocation=()');
    next();
  });

  app.use(express.json({ limit: '16kb' }));

  // Rate limit API endpoints
  app.use('/api', (req, res, next) => {
    const clientIp = req.ip || req.socket.remoteAddress || 'unknown';
    if (!checkRateLimit(clientIp)) {
      return res.status(429).json({ error: 'Too many requests. Please wait a moment and try again.' });
    }
    res.setHeader('Cache-Control', 'no-store, max-age=0');
    next();
  });

  app.get('/api/health', (_req, res) => {
    const config = getPublicNexconnConfig();
    res.json({
      status: 'ok',
      service: 'synapse-collective-intelligence',
      nexconnConfigured: config.configured,
      region: config.region,
      timestamp: new Date().toISOString(),
    });
  });

  app.get('/api/nexconn/config', (_req, res) => {
    res.json(getPublicNexconnConfig());
  });

  app.post('/api/nexconn/token', async (req, res) => {
    const { userId, name, avatarUrl } = req.body || {};
    if (typeof userId !== 'string' || typeof name !== 'string') {
      return res.status(400).json({ error: 'Both userId and name strings are required.' });
    }

    const result = await issueNexconnUserToken({
      userId,
      name,
      avatarUrl: typeof avatarUrl === 'string' ? avatarUrl : undefined,
    });

    if (!result.ok) {
      return res.status(result.status).json({ error: result.error });
    }

    return res.json({
      userId: result.userId,
      accessToken: result.accessToken,
    });
  });

  app.get('/api/nexconn/rooms', (_req, res) => {
    res.json({ rooms: listRooms() });
  });

  app.post('/api/nexconn/rooms', async (req, res) => {
    const { channelId, name, domain, description } = req.body || {};
    if (typeof channelId !== 'string') {
      return res.status(400).json({ error: 'channelId string is required.' });
    }

    const result = await ensureOpenChannelRoom({
      channelId,
      name: typeof name === 'string' ? name : undefined,
      domain: typeof domain === 'string' ? domain : undefined,
      description: typeof description === 'string' ? description : undefined,
    });

    if (!result.ok) {
      return res.status(result.status).json({ error: result.error });
    }

    return res.json({ room: result.room });
  });

  if (!isProduction) {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distDir = path.resolve(__dirname, 'dist');
    app.use(express.static(distDir, { index: false }));
    app.get('*', (_req, res) => {
      const indexFile = path.join(distDir, 'index.html');
      if (fs.existsSync(indexFile)) {
        res.sendFile(indexFile);
      } else {
        res.status(500).send('Production build not found. Run npm run build first.');
      }
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`SYNAPSE server running on http://0.0.0.0:${PORT} (${isProduction ? 'production' : 'development'})`);
  });
}

startServer().catch((err) => {
  console.error('Failed to start SYNAPSE server:', err);
  process.exit(1);
});

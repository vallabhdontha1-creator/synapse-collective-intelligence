import type { IncomingMessage, ServerResponse } from 'node:http';
import { checkRateLimit, issueNexconnUserToken } from '../../server/nexconnService';

type VercelRequest = IncomingMessage & {
  body?: Record<string, unknown>;
  headers: Record<string, string | string[] | undefined>;
};

type VercelResponse = ServerResponse & {
  status: (code: number) => VercelResponse;
  json: (data: unknown) => void;
};

export default async function handler(req: VercelRequest, res: VercelResponse) {
  res.setHeader('Cache-Control', 'no-store, max-age=0');
  if (req.method !== 'POST') {
    res.status(405).json({ error: 'Method not allowed' });
    return;
  }

  const forwarded = req.headers['x-forwarded-for'];
  const clientIp = Array.isArray(forwarded)
    ? forwarded[0]
    : (forwarded?.split(',')[0] || req.socket.remoteAddress || 'unknown');

  if (!checkRateLimit(clientIp)) {
    res.status(429).json({ error: 'Too many requests. Please wait a moment and try again.' });
    return;
  }

  const body = req.body || {};
  const userId = body.userId;
  const name = body.name;
  const avatarUrl = body.avatarUrl;

  if (typeof userId !== 'string' || typeof name !== 'string') {
    res.status(400).json({ error: 'Both userId and name strings are required.' });
    return;
  }

  const result = await issueNexconnUserToken({
    userId,
    name,
    avatarUrl: typeof avatarUrl === 'string' ? avatarUrl : undefined,
  });

  if (!result.ok) {
    res.status(result.status).json({ error: result.error });
    return;
  }

  res.status(200).json({
    userId: result.userId,
    accessToken: result.accessToken,
  });
}

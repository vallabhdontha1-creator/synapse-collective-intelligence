import type { IncomingMessage, ServerResponse } from 'node:http';
import { checkRateLimit, ensureOpenChannelRoom, listRooms } from '../../server/nexconnService';

type VercelRequest = IncomingMessage & {
  body?: Record<string, unknown>;
  headers: Record<string, string | string[] | undefined>;
};

type VercelResponse = ServerResponse & {
  status: (code: number) => VercelResponse;
  json: (data: unknown) => void;
};

export default async function handler(req: VercelRequest, res: VercelResponse) {
  res.setHeader('Cache-Control', 'no-store, max-age=0');

  if (req.method === 'GET') {
    res.status(200).json({ rooms: listRooms() });
    return;
  }

  if (req.method !== 'POST') {
    res.status(405).json({ error: 'Method not allowed' });
    return;
  }

  const forwarded = req.headers['x-forwarded-for'];
  const clientIp = Array.isArray(forwarded)
    ? forwarded[0]
    : (forwarded?.split(',')[0] || req.socket.remoteAddress || 'unknown');

  if (!checkRateLimit(clientIp)) {
    res.status(429).json({ error: 'Too many requests. Please wait a moment and try again.' });
    return;
  }

  const body = req.body || {};
  const channelId = body.channelId;
  if (typeof channelId !== 'string') {
    res.status(400).json({ error: 'channelId string is required.' });
    return;
  }

  const result = await ensureOpenChannelRoom({
    channelId,
    name: typeof body.name === 'string' ? body.name : undefined,
    domain: typeof body.domain === 'string' ? body.domain : undefined,
    description: typeof body.description === 'string' ? body.description : undefined,
  });

  if (!result.ok) {
    res.status(result.status).json({ error: result.error });
    return;
  }

  res.status(200).json({ room: result.room });
}

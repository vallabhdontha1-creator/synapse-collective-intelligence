import type { IncomingMessage, ServerResponse } from 'node:http';
import { getPublicNexconnConfig } from '../../server/nexconnService';

type VercelResponse = ServerResponse & {
  status: (code: number) => VercelResponse;
  json: (data: unknown) => void;
};

export default function handler(req: IncomingMessage, res: VercelResponse) {
  if (req.method !== 'GET') {
    res.status(405).json({ error: 'Method not allowed' });
    return;
  }
  res.setHeader('Cache-Control', 'no-store, max-age=0');
  res.status(200).json(getPublicNexconnConfig());
}

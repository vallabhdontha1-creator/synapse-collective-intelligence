import type { IncomingMessage, ServerResponse } from 'node:http';
import { getPublicNexconnConfig } from '../server/nexconnService';

type VercelResponse = ServerResponse & {
  status: (code: number) => VercelResponse;
  json: (data: unknown) => void;
};

export default function handler(_req: IncomingMessage, res: VercelResponse) {
  const config = getPublicNexconnConfig();
  res.setHeader('Cache-Control', 'no-store, max-age=0');
  res.status(200).json({
    status: 'ok',
    service: 'synapse-collective-intelligence',
    nexconnConfigured: config.configured,
    region: config.region,
    timestamp: new Date().toISOString(),
  });
}

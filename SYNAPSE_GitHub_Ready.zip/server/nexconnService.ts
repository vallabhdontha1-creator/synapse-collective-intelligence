import crypto from 'node:crypto';

export type NexconnRegion = 'SG' | 'NA' | 'SAU';

export interface RoomDefinition {
  channelId: string;
  name: string;
  domain: string;
  description: string;
  isCurated: boolean;
  createdAt: string;
}

const REGION_HOSTS: Record<NexconnRegion, [string, string]> = {
  SG: ['https://api.sg-light-api.com', 'https://api-b.sg-light-api.com'],
  NA: ['https://api.us-light-api.com', 'https://api-b.us-light-api.com'],
  SAU: ['https://api.sau-light-api.com', 'https://api-b.sau-light-api.com'],
};

const CURATED_ROOMS: RoomDefinition[] = [
  {
    channelId: 'synapse-global-commons',
    name: 'Global Commons',
    domain: 'Cross-Domain Synthesis',
    description:
      'Open collaborative channel for cross-disciplinary hypotheses, shared evidence logs, and network-wide synthesis.',
    isCurated: true,
    createdAt: '2026-11-01T00:00:00.000Z',
  },
  {
    channelId: 'synapse-climate-systems',
    name: 'Climate & Grid Systems',
    domain: 'Energy & Decarbonization',
    description:
      'Grid storage modeling, industrial decarbonization pathways, and peer-reviewed empirical telemetry.',
    isCurated: true,
    createdAt: '2026-11-01T00:00:00.000Z',
  },
  {
    channelId: 'synapse-biotech-research',
    name: 'Open Biotech Lab',
    domain: 'Computational Biology',
    description:
      'Assay reproducibility, molecular docking hypotheses, and collaborative literature synthesis.',
    isCurated: true,
    createdAt: '2026-11-01T00:00:00.000Z',
  },
  {
    channelId: 'synapse-civic-governance',
    name: 'Civic & Epistemic Governance',
    domain: 'Policy & Verification',
    description:
      'Structured consensus protocols, source verification frameworks, and public-interest institutional design.',
    isCurated: true,
    createdAt: '2026-11-01T00:00:00.000Z',
  },
];

const customRooms = new Map<string, RoomDefinition>();
const activeHostByRegion = new Map<NexconnRegion, string>();
const rateLimitBuckets = new Map<string, { count: number; resetAt: number }>();

export function normalizeRegion(raw?: string): NexconnRegion {
  const upper = (raw || 'SG').trim().toUpperCase();
  if (upper === 'NA' || upper === 'US') return 'NA';
  if (upper === 'SAU' || upper === 'OM' || upper === 'ME') return 'SAU';
  return 'SG';
}

export function getServerCredentials() {
  const appKey = (process.env.NEXCONN_APP_KEY || process.env.VITE_NEXCONN_APP_KEY || '').trim();
  const appSecret = (process.env.NEXCONN_APP_SECRET || '').trim();
  const region = normalizeRegion(process.env.NEXCONN_REGION || process.env.VITE_NEXCONN_REGION);
  return { appKey, appSecret, region };
}

export function getPublicNexconnConfig() {
  const { appKey, appSecret, region } = getServerCredentials();
  const missing: string[] = [];
  if (!appKey) missing.push('NEXCONN_APP_KEY');
  if (!appSecret) missing.push('NEXCONN_APP_SECRET');

  return {
    configured: missing.length === 0,
    appKey,
    region,
    missing,
  };
}

export function checkRateLimit(clientIp: string, maxRequests = 60, windowMs = 60_000): boolean {
  const now = Date.now();
  const key = clientIp || 'unknown';
  const entry = rateLimitBuckets.get(key);
  if (!entry || now > entry.resetAt) {
    rateLimitBuckets.set(key, { count: 1, resetAt: now + windowMs });
    return true;
  }
  if (entry.count >= maxRequests) {
    return false;
  }
  entry.count += 1;
  return true;
}

function buildSignedHeaders(appKey: string, appSecret: string): Record<string, string> {
  const nonce = crypto.randomBytes(8).toString('hex'); // 16 chars (<= 18)
  const timestamp = Date.now().toString();
  const signature = crypto
    .createHash('sha1')
    .update(`${appSecret}${nonce}${timestamp}`)
    .digest('hex');

  return {
    'App-Key': appKey,
    Nonce: nonce,
    Timestamp: timestamp,
    Signature: signature,
    'X-Request-ID': crypto.randomUUID(),
    'Content-Type': 'application/json',
  };
}

async function callNexconnServerApi<T>(
  path: string,
  payload: Record<string, unknown>,
): Promise<{ ok: boolean; status: number; data?: T & { code?: number; msg?: string; message?: string }; error?: string }> {
  const { appKey, appSecret, region } = getServerCredentials();
  if (!appKey || !appSecret) {
    return {
      ok: false,
      status: 503,
      error:
        'Nexconn server credentials are missing. Configure NEXCONN_APP_KEY and NEXCONN_APP_SECRET on the server.',
    };
  }

  const [primaryHost, backupHost] = REGION_HOSTS[region];
  const preferred = activeHostByRegion.get(region) || primaryHost;
  const fallback = preferred === primaryHost ? backupHost : primaryHost;
  const hostsToTry = [preferred, fallback];

  let lastError = 'Unable to reach Nexconn Platform API.';

  for (const host of hostsToTry) {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 5000);
    try {
      const response = await fetch(`${host}${path}`, {
        method: 'POST',
        headers: buildSignedHeaders(appKey, appSecret),
        body: JSON.stringify(payload),
        signal: controller.signal,
      });

      const text = await response.text();
      let parsed: (T & { code?: number; msg?: string; message?: string }) | undefined;
      try {
        parsed = text ? (JSON.parse(text) as T & { code?: number; msg?: string; message?: string }) : undefined;
      } catch {
        parsed = undefined;
      }

      if (response.ok) {
        activeHostByRegion.set(region, host);
        return { ok: true, status: response.status, data: parsed };
      }

      // Failover on 5xx; surface 4xx immediately (invalid signature, bad App Key, etc.)
      if (response.status >= 500) {
        lastError = `Nexconn API returned HTTP ${response.status} from ${host}`;
        continue;
      }

      return {
        ok: false,
        status: response.status,
        data: parsed,
        error:
          parsed?.msg ||
          parsed?.message ||
          `Nexconn API request failed with HTTP ${response.status}`,
      };
    } catch (err) {
      lastError = err instanceof Error ? err.message : 'Network timeout calling Nexconn API';
    } finally {
      clearTimeout(timeout);
    }
  }

  return { ok: false, status: 502, error: lastError };
}

const USER_ID_REGEX = /^[a-zA-Z0-9_-]{2,64}$/;
const CHANNEL_ID_REGEX = /^[a-zA-Z0-9_-]{3,64}$/;

export async function issueNexconnUserToken(params: {
  userId: string;
  name: string;
  avatarUrl?: string;
}) {
  const userId = params.userId.trim();
  const name = params.name.trim();
  const avatarUrl = params.avatarUrl?.trim();

  if (!USER_ID_REGEX.test(userId)) {
    return {
      ok: false as const,
      status: 400,
      error: 'userId must be 2–64 alphanumeric, underscore, or hyphen characters.',
    };
  }
  if (!name || name.length > 64) {
    return {
      ok: false as const,
      status: 400,
      error: 'Display name must be between 1 and 64 characters.',
    };
  }
  if (avatarUrl && (!/^https?:\/\//i.test(avatarUrl) || avatarUrl.length > 1024)) {
    return {
      ok: false as const,
      status: 400,
      error: 'avatarUrl must be a valid HTTP/HTTPS URL under 1024 characters.',
    };
  }

  const body: Record<string, string> = { userId, name };
  if (avatarUrl) body.avatarUrl = avatarUrl;

  const res = await callNexconnServerApi<{
    result?: { userId: string; accessToken: string };
  }>('/v4/auth/access-token/issue', body);

  if (!res.ok || !res.data || res.data.code !== 0 || !res.data.result?.accessToken) {
    return {
      ok: false as const,
      status: res.status || 502,
      error:
        res.error ||
        res.data?.msg ||
        res.data?.message ||
        `Nexconn token issuance failed (code: ${res.data?.code ?? 'unknown'})`,
    };
  }

  return {
    ok: true as const,
    status: 200,
    userId: res.data.result.userId,
    accessToken: res.data.result.accessToken,
  };
}

export async function ensureOpenChannelRoom(params: {
  channelId: string;
  name?: string;
  domain?: string;
  description?: string;
}) {
  const channelId = params.channelId.trim();
  if (!CHANNEL_ID_REGEX.test(channelId)) {
    return {
      ok: false as const,
      status: 400,
      error: 'channelId must be 3–64 alphanumeric, underscore, or hyphen characters.',
    };
  }

  // Create/ensure the open channel on Nexconn (destroyType: 0 = auto-destroy on 7 days of inactivity)
  const res = await callNexconnServerApi<Record<string, unknown>>('/v4/open-channel/create', {
    channelId,
    destroyType: 0,
    ttlMinutes: 10080,
  });

  // Note: code 0 = created; non-zero "already exists" codes vary by cluster; check HTTP 200 & code === 0 or common exists messages
  const code = res.data?.code;
  const msg = String(res.data?.msg || res.data?.message || res.error || '').toLowerCase();
  const alreadyExists = msg.includes('exist') || msg.includes('duplicate') || code === 10002 || code === 20005;

  if (!res.ok && !alreadyExists) {
    return {
      ok: false as const,
      status: res.status || 502,
      error: res.error || 'Failed to provision open channel on Nexconn.',
    };
  }

  if (code !== undefined && code !== 0 && !alreadyExists) {
    return {
      ok: false as const,
      status: 400,
      error: res.data?.msg || res.data?.message || `Nexconn open channel error (code ${code})`,
    };
  }

  const existingCurated = CURATED_ROOMS.find((r) => r.channelId === channelId);
  if (existingCurated) {
    return { ok: true as const, status: 200, room: existingCurated };
  }

  const existingCustom = customRooms.get(channelId);
  const room: RoomDefinition = existingCustom || {
    channelId,
    name: (params.name || channelId).trim().slice(0, 60),
    domain: (params.domain || 'Custom Collective').trim().slice(0, 48),
    description: (
      params.description ||
      'Real-time collaborative intelligence channel provisioned via Nexconn Open Channel API.'
    )
      .trim()
      .slice(0, 220),
    isCurated: false,
    createdAt: new Date().toISOString(),
  };

  customRooms.set(channelId, room);
  return { ok: true as const, status: 200, room };
}

export function listRooms(): RoomDefinition[] {
  return [...CURATED_ROOMS, ...Array.from(customRooms.values())];
}
